# Build CORE APK in GitHub Actions

This environment does not include the Android SDK or a reachable Gradle distribution server, so it cannot produce or validate an APK locally. This project includes a GitHub Actions workflow that can build a debug APK on a GitHub-hosted runner.

## Steps

1. Create a private repository on GitHub and upload the contents of this folder (the files inside `COREAndroid-AIDE`, not the parent folder).
2. Open the repository's **Actions** tab.
3. Select **Build APK** in the workflow list.
4. Press **Run workflow** and wait for it to finish.
5. Open the completed workflow run, scroll to **Artifacts**, and download `CORE-debug-apk`.
6. Extract the artifact ZIP and install `app-debug.apk` on your Android phone. You may need to allow installation from that file manager.

## Before relying on the app

- This workflow has not been executed in this environment; a successful build is not guaranteed until GitHub Actions completes.
- The archive contains placeholder notes instead of `libsd.so`, `libcore_llm.so`, and the Porcupine `hey_core.ppn` wake-word model. The APK may build without these optional runtime assets, but local inference and/or the custom wake word will not work until the appropriate licensed files are supplied. The Android speech recognizer and Digital Assistant integration are separate paths.
- Hosted Gemini use requires your own API key, configured inside the app with `/gemini setup`. Do not commit API keys or other secrets to the repository.
- Test phone control and voice activation after installation. Phone auto-run is OFF by default; plans that tap, type, read, call, or open URLs require approval unless you explicitly enable auto mode. Grant only the Android permissions you understand.
