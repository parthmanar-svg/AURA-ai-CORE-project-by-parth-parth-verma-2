# CORE hosted AI without running your own cloud worker

This build adds a direct hosted Gemini option for CORE's Android voice assistant, main chat, and multi-step phone agent. The direct route currently uses Google's stable `gemini-3.8-flash` model endpoint. You do **not** need to deploy a Cloudflare Worker or maintain a server for this route. Existing `/cloud` worker configuration remains supported.

## One-time setup

1. Build and install the Android app.
2. Open CORE and enter `/gemini setup` in its chat.
3. In the native Android dialog, paste your own Gemini API key and tap **Save key**. Do not paste the key into chat.
4. Enable CORE phone control with `/phone` and grant the Accessibility permission in Android settings.
5. Test with a low-risk command such as `open YouTube and search for lo-fi music`.

Use `/gemini status` to check whether a key is saved. If Simple Chat still reports an error, open the model menu and check the diagnostic text at the bottom; it should show Online and Gemini Direct. After saving the key, Simple Chat automatically switches to the hosted Gemini route. The Online model menu also exposes Gemini Direct even when no worker is configured. Auto mode tries this hosted route first when the key is present. The phone agent uses the same direct route and can fall back to your existing worker if one is set up. Use `/gemini off` to remove it from the app's private preferences. You can still use `/cloud https://your-worker.example TOKEN` if you already have a worker configured.

## Important notes

- A Google Gemini API key is still required. This removes the need to deploy/manage your own cloud server; it does not make hosted AI free or remove the provider's quotas, billing rules, or account requirements.
- The key is entered in a native password-masked Android dialog and stored in app-private SharedPreferences, not browser localStorage. This is not a hardware-backed secret vault; use a key with appropriate restrictions and revoke it if exposed.
- When a multi-step phone task is running, the agent sends the current screen's accessible text and task context to the hosted model so it can choose the next action. Do not use it on sensitive screens. The agent has guardrails for password/banking screens and destructive/payment-like actions, but these are not a guarantee.
- Android still requires user-granted Accessibility and microphone permissions. Android/other apps may block some actions. Keep confirmation prompts enabled for sensitive actions; don't enable unattended automation for tasks involving money, account changes, deletion, or private messages.
- The existing wake-word listener may require a Picovoice AccessKey. You can also invoke CORE through Android's Digital assistant settings where supported.
- This source update has not been built against an Android SDK in this environment. Build and test it in Android Studio/AIDE before relying on it on your main device.
