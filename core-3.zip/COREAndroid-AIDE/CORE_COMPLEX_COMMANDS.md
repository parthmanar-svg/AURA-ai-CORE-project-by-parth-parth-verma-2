# CORE AI — Complex command support (development patch)

This patch extends deterministic local command handling and gives online models a clearer phone-agent contract. It does not add new Android privileges or bypass Android's security model.

## Local commands added
- `search YouTube for algebra basics`
- `find algebra basics on YouTube`
- `search maps for nearby libraries`
- `navigate to India Gate`
- `directions to the railway station`
- `set alarm for 7:30 pm`
- `text +911234567890 saying I will be late`

Hindi/Hinglish examples already supported by the existing parser include `YouTube kholo`, `awaaz badhao`, `peeche jao`, and `neeche scroll karo`.

## Complex online agent
When an online provider is configured and phone control is enabled, the prompt now explicitly guides the model to:
- turn multi-step requests into ordered plans (up to 12 actions),
- use YouTube and Maps URLs for app-specific searches/navigation,
- prefer text-based accessibility actions over guessed screen coordinates,
- open message composers rather than falsely claiming a message was sent,
- report completion only after the phone returns results.

## Important limitations
- The Android project must still be built and tested on a real device.
- Online multi-step planning requires a working provider; offline mode only handles deterministic commands.
- The OS may show app chooser, permission, or confirmation screens. CORE cannot silently bypass those.
- SMS actions open a composer; the user remains responsible for reviewing and sending the message.
- Navigation URLs open Maps/browser and do not guarantee turn-by-turn navigation starts automatically.
