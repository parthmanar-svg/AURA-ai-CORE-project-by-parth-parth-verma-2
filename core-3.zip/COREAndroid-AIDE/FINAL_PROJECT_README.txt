CORE — Full Android AI Assistant Project

This folder contains the full project source in one place, including:
- General-purpose AI chat UI and cloud AI integration
- Voice input / wake service components
- Agent/task runner and command routing
- Phone-control bridge and accessibility service components
- Web assets, vendor assets, Android manifest and Gradle files
- Cloud worker/configuration files and GitHub Actions build workflow

Architecture note:
CORE is intended to be a general-purpose AI assistant first. Phone control is a tool/subsystem that CORE may use when a task requires it; ordinary chat should remain ordinary AI chat.

Latest included chat UI fix:
The simple chat UI now includes the scMic voice-input button expected by core-simple.js, preventing the reported null addEventListener startup exception.

Build/testing status:
The project source is packaged together, but a complete Android build and on-device runtime test have not been verified in this environment. The jniLibs directory contains placeholder notes for native libraries, so any feature requiring those native runtimes may need the corresponding libraries supplied. See README_AIDE.txt, BUILD_ON_GITHUB.md, PREBUILD_AUDIT.md, CLOUD_SETUP.md and tools/README_MODELS.txt for project-specific setup notes.

Start here:
1. Open COREAndroid-AIDE/ in Android Studio or a compatible Android IDE.
2. Read README_AIDE.txt and BUILD_ON_GITHUB.md.
3. Review CLOUD_SETUP.md before using cloud features; do not commit API keys or secrets.
