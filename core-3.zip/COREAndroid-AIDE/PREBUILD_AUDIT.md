# CORE pre-build wiring and static audit

## Changes made

- Wired the direct Gemini bridge into the main WebView chat path, not just the voice assistant and multi-step agent. The API key remains in app-private Android preferences and is not returned to JavaScript.
- Fixed Simple Chat provider discovery: a direct Gemini key now appears as a hosted provider even without a Cloudflare worker, Auto mode tries it first, and saving the key automatically switches Simple Chat to hosted mode.
- Added a native asynchronous chat callback with a bounded timeout and output-token cap.
- Updated the direct Gemini endpoint to Google's currently documented stable `gemini-3.8-flash` model.
- Changed all missing-preference defaults for phone auto-run to **off**. Sensitive action plans and voice-agent tasks now ask for approval unless the user explicitly enables `/phone auto on` through the native confirmation dialog.
- Updated setup/build documentation to describe the wired path and known runtime asset placeholders.

## Checks completed in this environment

- ZIP integrity checks passed for the input and generated archives.
- Parsed every Android XML resource and the manifest successfully.
- `node --check` passed for the modified `core-simple.js` and `core-phone.js` JavaScript assets.
- Java compiler was run as a syntax pass. It could not type-check Android classes because no Android SDK / `android.jar` is installed; no Java syntax diagnostics were found.
- Verified there are no obvious hard-coded Gemini/API secrets in the project.
- Verified direct Gemini wiring references exist on both the native bridge and JavaScript callback path, and that auto-run no longer defaults to true.

## Not verified

- A real Gradle/Android build could not run: the environment has no Android SDK or cached Gradle distribution, and outbound DNS/network access to `services.gradle.org` failed.
- No APK was produced, and no device/runtime test was possible. GitHub Actions still needs to run a real build. The placeholder `libsd.so`, `libcore_llm.so`, and Porcupine wake-word model mean those optional local inference / custom wake-word features are not ready until licensed assets are supplied.
- API credentials, quota, and runtime calls cannot be validated without a user's own Gemini API key and network access.

## First device smoke test

1. Install the debug APK built by GitHub Actions.
2. Open CORE and run `/gemini setup`, then `/gemini status`. Saving the key should automatically switch Simple Chat to Online → Gemini Direct.
3. Send a normal question to confirm main chat uses hosted Gemini. If it fails, capture the exact error and the model-menu diagnostic text.
4. Send `/phone`, enable Android Accessibility for CORE, then try `open YouTube and search for lo-fi music`.
5. Confirm tapping/typing actions ask for approval. Only test `/phone auto on` after reviewing the native warning; use `/phone auto off` to restore approvals.
6. Test `/wake` separately; custom Porcupine wake-word support needs its licensed keyword asset and access key.
