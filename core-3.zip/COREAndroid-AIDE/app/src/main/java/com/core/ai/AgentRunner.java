package com.core.ai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 * Multi-step task runner: look at the screen, ask the model for ONE next action, do it, look again.
 * Runs inside the accessibility service (so Android keeps it alive), is capped at MAX_STEPS,
 * can be stopped from the notification, and refuses sensitive apps, password fields and anything that looks like spending money.
 * Screen text is sent to your CORE Cloud model while a task runs. Nothing is sent when no task is running.
 */
final class AgentRunner {
    private AgentRunner() { }

    static final int MAX_STEPS = 30;
    static volatile boolean active = false;
    private static volatile boolean stop = false;
    private static final int NOTE_ID = 9;
    private static final String CHANNEL = "core_task";

    // labels the agent may never press, whatever the model says
    private static final Pattern DENY = Pattern.compile(
            "(?i)(\\b(pay|buy|purchase|order|checkout|transfer|donate|join|upgrade|delete|uninstall|reset|install|erase|wipe|confirm payment)\\b|[$\\u20ac\\u00a3\\u20b9\\u00a5])");

    private static final String SYS =
            "You control an Android phone to finish the user's goal, one step at a time. "
            + "Each turn you get the goal, the steps already taken, and the current screen as a numbered list. "
            + "Reply with ONE JSON object and nothing else. Actions:\n"
            + "{\"do\":\"open\",\"app\":\"YouTube\"}\n"
            + "{\"do\":\"url\",\"url\":\"https://www.youtube.com/results?search_query=...\"}  (opens in the matching app)\n"
            + "{\"do\":\"tap_id\",\"id\":12}   (press or focus item [12] from the list)\n"
            + "{\"do\":\"type\",\"text\":\"...\"}   (types into the focused text box; tap_id the box first)\n"
            + "{\"do\":\"scroll\",\"dir\":\"down\"}  {\"do\":\"back\"}  {\"do\":\"home\"}  {\"do\":\"wait\",\"ms\":1500}\n"
            + "{\"do\":\"done\",\"say\":\"short spoken summary\"}   when the goal is finished\n"
            + "{\"do\":\"fail\",\"say\":\"why you could not finish\"}\n"
            + "Rules: use only ids from the CURRENT list. Check that a step worked (for example the item shows as on/selected) before moving on. "
            + "If a screen has not changed, try something different, not the same step. Never touch password fields, payments, purchases, memberships or deletions. "
            + "Only say done when the screen proves it. For YouTube: a results URL is the fastest way to search; Subscribe, Like and the comment box are on the video page, scroll if needed.";

    static void cancel() { stop = true; }

    static void start(final PhoneControlService svc, final String goal) {
        if (active) { toast(svc, "A task is already running."); return; }
        stop = false;
        active = true;
        notifyRunning(svc, goal);
        new Thread(new Runnable() {
            public void run() {
                String result;
                try { result = loop(svc, goal); }
                catch (Throwable t) { result = "Stopped: " + t.getMessage(); }
                active = false;
                clearNote(svc);
                toast(svc, result);
                AssistActivity.say(svc, result);
            }
        }).start();
    }

    private static String loop(PhoneControlService svc, String goal) throws Exception {
        SharedPreferences sp = svc.getSharedPreferences("core_phone", Context.MODE_PRIVATE);
        String base = sp.getString("cloud_url", ""), tok = sp.getString("cloud_token", "");
        if (base.length() == 0 || tok.length() == 0) return "Set up CORE Cloud first (send /cloud in the app).";
        ArrayList<String> history = new ArrayList<String>();
        String lastScreen = "";
        int same = 0;
        Thread.sleep(250);
        for (int step = 1; step <= MAX_STEPS; step++) {
            if (stop) return "Stopped.";
            if (PhoneControlService.instance == null) return "The accessibility service stopped.";
            if (svc.isProtectedScreen()) return "Stopped: a banking or password app is on screen.";
            String screen = svc.dumpUi(70);
            same = screen.equals(lastScreen) ? same + 1 : 0;
            lastScreen = screen;
            if (same >= 3) return "Stopped: the screen stopped changing.";
            StringBuilder u = new StringBuilder();
            u.append("GOAL: ").append(goal).append("\n\nSTEPS SO FAR:\n");
            int from = Math.max(0, history.size() - 10);
            if (history.size() == 0) u.append("(none yet)\n");
            for (int i = from; i < history.size(); i++) u.append(i + 1).append(". ").append(history.get(i)).append('\n');
            u.append("\nCURRENT SCREEN:\n").append(screen).append("\nNext action (JSON only):");
            String reply = ask(base, tok, u.toString());
            JSONObject a = firstJson(reply);
            if (a == null) { history.add("(model gave no valid action)"); if (history.size() > 6) return "Stopped: the model kept answering badly."; continue; }
            String d = a.optString("do");
            if ("done".equals(d)) return a.optString("say", "Done.");
            if ("fail".equals(d)) return "Couldn\u2019t finish: " + a.optString("say", "unknown reason");
            String err = null;
            if ("tap_id".equals(d)) {
                int id = a.optInt("id", -1);
                String label = svc.labelOf(id);
                if (DENY.matcher(label).find()) err = "refused to press \u201c" + label + "\u201d (looks like money or a destructive action)";
                else if (!svc.tapId(id)) err = "couldn\u2019t press item " + id;
                history.add(err == null ? "pressed [" + id + "] \u201c" + label + "\u201d" : "FAILED: " + err);
            } else {
                JSONObject r = PhoneBridge.exec(svc, a);
                if (!r.optBoolean("ok")) err = r.optString("error", d + " failed");
                String what = d + (a.has("text") ? " \u201c" + a.optString("text") + "\u201d" : a.has("app") ? " " + a.optString("app") : a.has("url") ? " " + a.optString("url") : "");
                history.add(err == null ? what : "FAILED: " + what + " (" + err + ")");
            }
            if (err != null && err.startsWith("refused")) return "Stopped: " + err;
            Thread.sleep("wait".equals(d) ? 150 : 800);
        }
        return "Stopped after " + MAX_STEPS + " steps. Ask me to continue if it isn\u2019t finished.";
    }

    private static JSONObject firstJson(String t) {
        if (t == null) return null;
        int i = t.indexOf('{'), j = t.lastIndexOf('}');
        if (i < 0 || j <= i) return null;
        try { return new JSONObject(t.substring(i, j + 1)); } catch (Exception e) { return null; }
    }

    private static String ask(String base, String tok, String user) throws Exception {
        JSONArray msgs = new JSONArray();
        msgs.put(new JSONObject().put("role", "system").put("content", SYS));
        msgs.put(new JSONObject().put("role", "user").put("content", user));
        JSONObject body = new JSONObject().put("messages", msgs).put("max_tokens", 300);
        HttpURLConnection c = (HttpURLConnection) new URL(base + "/v1/chat").openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(40000);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("Authorization", "Bearer " + tok);
        OutputStream os = c.getOutputStream();
        os.write(body.toString().getBytes("UTF-8"));
        os.close();
        if (c.getResponseCode() != 200) throw new Exception("CORE Cloud error " + c.getResponseCode());
        BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String ln;
        while ((ln = br.readLine()) != null) {
            ln = ln.trim();
            if (!ln.startsWith("data:")) continue;
            String d = ln.substring(5).trim();
            if (d.equals("[DONE]")) break;
            try {
                JSONArray ch = new JSONObject(d).optJSONArray("choices");
                if (ch == null || ch.length() == 0) continue;
                JSONObject delta = ch.getJSONObject(0).optJSONObject("delta");
                if (delta == null || !delta.has("content") || delta.isNull("content")) continue;
                sb.append(delta.getString("content"));
            } catch (Exception ignore) { }
        }
        br.close();
        return sb.toString();
    }

    // ---- notification with Stop ----------------------------------------------------------------

    private static void notifyRunning(Context c, String goal) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            Notification.Builder nb;
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel(CHANNEL, "CORE tasks", NotificationManager.IMPORTANCE_LOW));
                nb = new Notification.Builder(c, CHANNEL);
            } else nb = new Notification.Builder(c);
            PendingIntent stopPi = PendingIntent.getBroadcast(c, 3, new Intent(c, AgentStopReceiver.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            nb.setContentTitle("CORE is working on your phone")
              .setContentText(goal.length() > 80 ? goal.substring(0, 80) : goal)
              .setSmallIcon(android.R.drawable.ic_menu_manage)
              .setOngoing(true)
              .addAction(android.R.drawable.ic_menu_close_clear_cancel, "STOP", stopPi);
            nm.notify(NOTE_ID, nb.build());
        } catch (Exception e) { }
    }

    private static void clearNote(Context c) {
        try { ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(NOTE_ID); } catch (Exception e) { }
    }

    private static void toast(final Context c, final String m) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            public void run() { try { Toast.makeText(c, m.length() > 300 ? m.substring(0, 300) : m, Toast.LENGTH_LONG).show(); } catch (Exception e) { } }
        });
    }
}
