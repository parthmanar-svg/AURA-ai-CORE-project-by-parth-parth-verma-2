package com.core.ai;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** The Stop button on the CORE task notification. */
public class AgentStopReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) { AgentRunner.cancel(); }
}
