package com.core.ai;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognitionService;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The "hold Home" assistant: a small translucent card that listens, understands and acts.
 * Quick commands run locally; anything else goes to CORE Cloud (settings saved by the app via /cloud).
 * The card closes before actions run, so taps/typing/reading hit the app you were in.
 */
public class AssistActivity extends Activity {
    private static final int REQ_MIC = 77;
    private static final Pattern PLAN = Pattern.compile("```phone\\s*([\\s\\S]*?)```");
    private static final String SYS = "You are CORE, a voice assistant on the user\u2019s Android phone. Reply in one or two short spoken sentences, no markdown. "
            + "You can control the phone. When (and only when) the user asks you to do something on the phone, end your reply with one fenced block labelled phone containing a JSON array of actions, for example:\n"
            + "```phone\n[{\"do\":\"open\",\"app\":\"YouTube\"}]\n```\n"
            + "Actions: home, back, recents, notifications, quick, scroll{dir:up|down}, volume{dir:up|down}, open{app}, tap{x,y}, swipe{x1,y1,x2,y2}, click{text}, type{text}, read, dial{number}, sms{number,text}, url{url}, alarm{hour,min,label}, wait{ms}, media{key:play|pause|next|prev}, torch{on:true|false}, screenshot, lock, power, settings{page:wifi|bluetooth|airplane|display|sound|battery|location|apps}, longpress{x,y}, intent{action,data,package,type,extras}. "
            + "Keep plans short. You only send the plan, so never claim it already happened.";

    private static TextToSpeech TTS;
    private static ComponentName RECOG;
    private static boolean recogResolved = false;
    private int spokenTo = 0;
    private boolean streamSpoke = false;

    /** Pre-warm TTS and the recognizer lookup so the first hold-Home is instant. */
    static void warm(Context c) {
        try { initTts(c.getApplicationContext()); resolveRecognizer(c.getApplicationContext()); } catch (Exception e) { }
    }
    private static volatile boolean TTS_OK = false;

    private TextView title, body, again;
    private OrbView orb;
    private View panel;
    private boolean closing = false;
    private SpeechRecognizer rec;
    private SharedPreferences sp;
    private volatile boolean busy = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("core_phone", Context.MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        else getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        initTts(getApplicationContext());

        getWindow().setDimAmount(0.38f);
        FrameLayout root = new FrameLayout(this);
        root.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { closeAnimated(); } });

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(24), dp(14), dp(24), dp(34));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFA0D1217);
        float r = dp(30);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        bg.setStroke(dp(1), 0x26FFFFFF);
        card.setBackground(bg);
        card.setClickable(true);
        panel = card;

        // grab handle
        View handle = new View(this);
        GradientDrawable hb = new GradientDrawable();
        hb.setColor(0x33FFFFFF);
        hb.setCornerRadius(dp(2));
        handle.setBackground(hb);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(dp(36), dp(4));
        hp.gravity = Gravity.CENTER_HORIZONTAL;
        hp.bottomMargin = dp(10);
        card.addView(handle, hp);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        orb = new OrbView(this);
        title = new TextView(this);
        title.setTextColor(0xFF8A96A0);
        title.setTextSize(13);
        title.setText("CORE");
        head.addView(orb);
        head.addView(title);

        body = new TextView(this);
        body.setTextColor(0xFFF2F5F7);
        body.setTextSize(22);
        body.setTypeface(android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL));
        body.setLineSpacing(0f, 1.1f);
        body.setPadding(dp(4), dp(6), dp(4), dp(10));
        body.setMinHeight(dp(56));

        again = new TextView(this);
        again.setText("Tap to speak");
        again.setTextColor(0xFF00D7FF);
        again.setTextSize(14);
        again.setGravity(Gravity.CENTER);
        again.setPadding(dp(22), dp(10), dp(22), dp(10));
        GradientDrawable pill = new GradientDrawable();
        pill.setColor(0x1400D7FF);
        pill.setCornerRadius(dp(24));
        pill.setStroke(dp(1), 0x6600D7FF);
        again.setBackground(pill);
        again.setClickable(true);
        again.setVisibility(View.GONE);
        again.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { listen(); } });

        card.addView(head);
        card.addView(body);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ap.gravity = Gravity.CENTER_HORIZONTAL;
        ap.topMargin = dp(4);
        card.addView(again, ap);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        root.addView(card, lp);
        setContentView(root);

        // slide-up entrance
        card.setTranslationY(dp(90));
        card.setAlpha(0f);
        card.animate().translationY(0f).alpha(1f).setDuration(170)
                .setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f)).start();
        begin();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        begin();
    }

    /** Wake word with words after it ("hey core open youtube") skips listening and runs the command. */
    private void begin() {
        closing = false;
        String c = getIntent() == null ? null : getIntent().getStringExtra("cmd");
        if (c != null && c.trim().length() > 0) { getIntent().removeExtra("cmd"); handle(c.trim()); }
        else listen();
    }

    @Override
    protected void onDestroy() {
        destroyRec();
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_MIC) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) listen();
            else fail("I need the microphone permission to hear you.");
        }
    }

    private void closeAnimated() {
        if (closing) return;
        closing = true;
        destroyRec();
        if (panel == null) { finish(); return; }
        panel.animate().translationY(dp(90)).alpha(0f).setDuration(180)
                .withEndAction(new Runnable() { public void run() { finish(); } }).start();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    // ------------------------------------------------------------------ listening

    private void listen() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        if (busy) return;
        title.setText("Listening\u2026");
        body.setText("");
        again.setVisibility(View.GONE);
        orb.setState(OrbView.LISTEN);
        destroyRec();
        if (ChirpStt.preferred(this) && ChirpStt.configured(this)) { chirp(); return; }
        try {
            rec = createRecognizer();
            rec.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle p) { }
                public void onBeginningOfSpeech() { }
                public void onRmsChanged(float v) { orb.setRms(v); }
                public void onBufferReceived(byte[] buf) { }
                public void onEndOfSpeech() { }
                public void onEvent(int type, Bundle p) { }
                public void onPartialResults(Bundle p) {
                    ArrayList<String> l = p == null ? null : p.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (l != null && l.size() > 0) body.setText(l.get(0));
                }
                public void onResults(Bundle r) {
                    ArrayList<String> l = r == null ? null : r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (l != null && l.size() > 0 && l.get(0).trim().length() > 0) { alts = l; handle(l.get(0)); }
                    else fail("I didn\u2019t catch that.");
                }
                public void onError(int e) {
                    if (e != SpeechRecognizer.ERROR_NO_MATCH && e != SpeechRecognizer.ERROR_SPEECH_TIMEOUT && e != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS && ChirpStt.configured(AssistActivity.this)) { chirp(); return; }
                    if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) fail("I didn\u2019t catch that.");
                    else fail("Speech recognition error " + e + ".");
                }
            });
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            i.putExtra("android.speech.extras.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 900L);
            i.putExtra("android.speech.extras.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 700L);
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L);
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 700L);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
            rec.startListening(i);
        } catch (Exception e) {
            fail("Speech recognition isn\u2019t available on this phone.");
        }
    }

    /** Use another app's recognizer (Google's if present): CORE registers a stub recognizer that must not be picked. */
    private SpeechRecognizer createRecognizer() {
        ComponentName pick = resolveRecognizer(this);
        return pick != null ? SpeechRecognizer.createSpeechRecognizer(this, pick) : SpeechRecognizer.createSpeechRecognizer(this);
    }

    private static synchronized ComponentName resolveRecognizer(Context c) {
        if (recogResolved) return RECOG;
        ComponentName pick = null;
        try {
            List<ResolveInfo> l = c.getPackageManager().queryIntentServices(new Intent(RecognitionService.SERVICE_INTERFACE), 0);
            for (ResolveInfo ri : l) {
                if (ri.serviceInfo == null || c.getPackageName().equals(ri.serviceInfo.packageName)) continue;
                ComponentName cn = new ComponentName(ri.serviceInfo.packageName, ri.serviceInfo.name);
                if (ri.serviceInfo.packageName.contains("google")) { pick = cn; break; }
                if (pick == null) pick = cn;
            }
        } catch (Exception e) { }
        RECOG = pick; recogResolved = true;
        return pick;
    }

    private void destroyRec() {
        if (rec != null) { try { rec.destroy(); } catch (Exception e) { } rec = null; }
    }

    private void fail(String msg) {
        title.setText("CORE");
        body.setText(msg);
        again.setVisibility(View.VISIBLE);
        orb.setState(OrbView.IDLE);
    }

    private void show(final String text) {
        runOnUiThread(new Runnable() {
            public void run() {
                title.setText("CORE");
                body.setText(text);
                again.setVisibility(View.VISIBLE);
                orb.setState(OrbView.RESPOND);
            }
        });
    }

    // ------------------------------------------------------------------ understanding

    private void handle(final String said) {
        busy = true;
        title.setText("You said");
        body.setText(said);
        again.setVisibility(View.GONE);
        orb.setState(OrbView.THINK);
        new Thread(new Runnable() {
            public void run() {
                try { process(said.trim()); }
                catch (Exception e) { show("Something went wrong: " + e.getMessage()); }
                busy = false;
            }
        }).start();
    }

    private volatile java.util.List<String> alts = null;

    private void chirp() {
        destroyRec();
        title.setText("Listening\u2026");
        orb.setState(OrbView.LISTEN);
        ChirpStt.listen(this, "en-US", new ChirpStt.Callback() {
            public void onResult(ArrayList<String> l) { alts = l; handle(l.get(0)); }
            public void onError(String m) { fail(m); }
        });
    }

    /** All STT hypotheses go to the AI so it can fix mishearings. */
    private String altNote() {
        java.util.List<String> a = alts;
        if (a == null || a.size() < 2) return "";
        StringBuilder sb = new StringBuilder(" Speech-to-text heard these alternatives, best guess first: ");
        for (int k = 0; k < a.size() && k < 5; k++) sb.append(k > 0 ? " | " : "").append('"').append(a.get(k)).append('"');
        return sb.append(". If the best guess looks like a mishearing, use the alternative that makes sense.").toString();
    }
    private boolean resumeNext = false;

    private void process(String phrase) throws Exception {
        String lp = phrase.toLowerCase(java.util.Locale.US).trim().replaceAll("[.!?,]+$", "");
        if (lp.matches("(?:stop|cancel|abort|quit|enough|shut up|never ?mind)(?: it| that| the task)?")) { AgentRunner.cancel(); show("Stopped."); return; }
        String cu = sp.getString("cloud_url", ""), ct = sp.getString("cloud_token", "");
        String directKey = sp.getString("gemini_api_key", "");
        boolean cloud = (cu.length() > 0 && ct.length() > 0) || directKey.length() > 0;
        if (cloud && SETTING_WORD.matcher(lp).find() && ONOFF_WORD.matcher(lp).find() && !lp.contains("settings")) { askAgent(phrase); return; }
        if (lp.matches("(?:please )?(?:continue|keep going|resume|carry on)(?: the task| that)?")) {
            if (AgentRunner.canResume()) { resumeNext = true; askAgent(AgentRunner.lastGoal()); }
            else show("Nothing to continue. Tell me a new task.");
            return;
        }
        JSONArray fast = FastCommands.parse(phrase);
        if (fast != null && fast.length() == 1 && "unlock".equals(fast.optJSONObject(0).optString("do"))) { unlockPhone(); return; }
        if (cloud && looksLikeTask(phrase)) { askAgent(phrase); return; }   // AI first; AgentRunner falls back to the offline engine if the cloud is unreachable
        if (fast != null) { runPlan(fast); return; }   // no cloud (or not task-shaped): quick commands
        if (!cloud && looksLikeTask(phrase) && OfflineAgent.canHandle(phrase)) { askAgent(phrase); return; }   // no cloud: on-phone step engine
        if (!cloud) { JSONArray bare = FastCommands.bareApp(phrase); if (bare != null) { runPlan(bare); return; } }
        String url = sp.getString("cloud_url", ""), tok = sp.getString("cloud_token", "");
        if ((url.length() > 0 && tok.length() > 0 || directKey.length() > 0) && looksLikeTask(phrase)) { askAgent(phrase); return; }
        if ((url.length() == 0 || tok.length() == 0) && directKey.length() == 0) {
            show("Try steps like: \u201cyt lofi, play first result\u201d, \u201copen instagram, search cats, like\u201d, \u201ctap settings then scroll down\u201d.");
            return;
        }
        spokenTo = 0; streamSpoke = false;
        String reply = directKey.length() > 0 ? directGeminiChat(directKey, phrase) : cloudChat(url, tok, phrase);
        Matcher m = PLAN.matcher(reply);
        String clean = reply.trim();
        JSONArray plan = null;
        if (m.find()) {
            clean = reply.replace(m.group(0), "").trim();
            try { plan = new JSONArray(m.group(1).trim()); }
            catch (Exception e) { clean = (clean + " (The phone plan was malformed.)").trim(); }
        }
        if (clean.length() > 0) {
            show(clean);
            if (streamSpoke) {
                int kk = reply.indexOf("```phone");
                String sp0 = kk >= 0 ? reply.substring(0, kk) : reply;
                speak(sp0.substring(Math.min(spokenTo, sp0.length())).trim());
            } else speak(clean);
        }
        if (plan != null && plan.length() > 0) runPlan(plan);
    }

    private static final Pattern TASK = Pattern.compile("(?i)\\b(open|go to|search|subscribe|like|comment|post|send|play|find|follow|add|set|turn|download|watch|reply|share|message|text|navigate|book|keep going|then)\\b");

    private static final Pattern NOT_TASK = Pattern.compile("(?i)^(what|whats|who|whom|whose|why|how|when|where|which|is|are|was|were|am|do|does|did|can|could|would|should|will|tell|explain|define|describe|translate|write|hello|hi|hey|yo|thanks|thank|thx|ok|okay|yes|no|nope|sure|good|nice|wow|lol|i|im|my|we|you|it|that|this|there)\\b");
    private static final Pattern SETTING_WORD = Pattern.compile("(?i)\\b(wifi|wi-fi|bluetooth|airplane mode|flight mode|mobile data|hotspot|location|gps|do not disturb|dnd|battery saver|auto ?rotate|dark mode|nfc)\\b");
    private static final Pattern ONOFF_WORD = Pattern.compile("(?i)\\b(turn|switch|toggle|enable|disable|on|off)\\b");

    /** Blunt, short, command-shaped phrases count as tasks ("yt lofi", "wifi off", "dark mode"); questions and chit-chat stay chat. */
    private boolean looksLikeTask(String p) {
        String t = p.toLowerCase(java.util.Locale.US).trim();
        if (t.endsWith("?")) return false;
        if (t.startsWith("do ") || t.startsWith("task ") || TASK.matcher(t).find()) return true;
        if (NOT_TASK.matcher(t).find()) return false;
        return t.split("\\s+").length <= 7;
    }

    /** Multi-step jobs: show exactly what will happen, then (after unlock if needed) hand over to AgentRunner. */
    private void askAgent(final String goal) {
        if (!sp.getBoolean("enabled", false)) { show("Phone control is off. Open CORE and send /phone to turn it on."); return; }
        if (PhoneControlService.instance == null) { show("Switch on the CORE accessibility service first (send /phone in the app)."); return; }
        final Runnable go = new Runnable() {
            public void run() {
                KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                if (km != null && km.isKeyguardLocked()) {
                    if (Build.VERSION.SDK_INT >= 26) {
                        title.setText("Unlock to continue");
                        km.requestDismissKeyguard(AssistActivity.this, new KeyguardManager.KeyguardDismissCallback() {
                            @Override public void onDismissSucceeded() { launchAgent(goal); }
                            @Override public void onDismissCancelled() { show("Still locked, so I stopped."); }
                            @Override public void onDismissError() { show("I couldn\u2019t open the unlock screen."); }
                        });
                    } else show("Unlock your phone, then ask again.");
                } else launchAgent(goal);
            }
        };
        runOnUiThread(new Runnable() {
            public void run() {
                if (isFinishing()) return;
                if (sp.getBoolean("auto", false)) { go.run(); return; }
                new AlertDialog.Builder(AssistActivity.this)
                        .setTitle("Run this task?")
                        .setMessage("\u201c" + goal + "\u201d\n\nCORE will look at your screen and tap and type for up to " + AgentRunner.MAX_STEPS
                                + " steps. Screen text is sent to your CORE Cloud model while it works. It won\u2019t touch password fields or payments. You can stop it from the notification.")
                        .setCancelable(false)
                        .setPositiveButton("Run", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) { go.run(); } })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) { show("Cancelled."); } })
                        .show();
            }
        });
    }

    private void launchAgent(String goal) {
        PhoneControlService s = PhoneControlService.instance;
        if (s == null) { show("The accessibility service stopped."); return; }
        runOnUiThread(new Runnable() { public void run() { finish(); } });
        boolean rs = resumeNext; resumeNext = false;
        AgentRunner.altHint = altNote();
        AgentRunner.start(s, goal, rs);
    }

    private String directGeminiChat(String apiKey, String userText) throws Exception {
        JSONArray msgs = new JSONArray();
        msgs.put(new JSONObject().put("role", "system").put("content", SYS + altNote()));
        msgs.put(new JSONObject().put("role", "user").put("content", userText));
        return CloudAi.geminiDirect(apiKey, msgs, 400);
    }

    private String cloudChat(String base, String tok, String userText) throws Exception {
        JSONArray msgs = new JSONArray();
        msgs.put(new JSONObject().put("role", "system").put("content", SYS + altNote()));
        msgs.put(new JSONObject().put("role", "user").put("content", userText));
        JSONObject body = new JSONObject().put("messages", msgs).put("max_tokens", 250);
        if (CloudAi.geminiPreferred(this)) return CloudAi.gemini(base, tok, msgs, 300);
        HttpURLConnection c = (HttpURLConnection) new URL(base + "/v1/chat").openConnection();
        c.setConnectTimeout(5000);
        c.setReadTimeout(30000);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("Authorization", "Bearer " + tok);
        OutputStream os = c.getOutputStream();
        os.write(body.toString().getBytes("UTF-8"));
        os.close();
        if (c.getResponseCode() != 200) throw new IOException("CORE Cloud error " + c.getResponseCode());
        BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String ln;
        while ((ln = br.readLine()) != null) {
            ln = ln.trim();
            if (!ln.startsWith("data:")) continue;
            String d = ln.substring(5).trim();
            if (d.equals("[DONE]")) break;
            try {
                JSONArray ch = new JSONObject(d).optJSONArray("choices");
                if (ch == null || ch.length() == 0) continue;
                JSONObject delta = ch.getJSONObject(0).optJSONObject("delta");
                if (delta == null || !delta.has("content") || delta.isNull("content")) continue;
                String t = delta.getString("content");
                if (t.length() > 0) {
                    sb.append(t);
                    String vis = sb.toString();
                    int k = vis.indexOf("```phone");
                    String shown = k >= 0 ? vis.substring(0, k) : vis;
                    show(shown.trim());
                    int e = spokenTo;
                    for (int q = spokenTo; q < shown.length() - 1; q++) {
                        char sc = shown.charAt(q);
                        if ((sc == '.' || sc == '!' || sc == '?') && Character.isWhitespace(shown.charAt(q + 1))) e = q + 1;
                    }
                    if (e > spokenTo) { speak(shown.substring(spokenTo, e).trim()); spokenTo = e; streamSpoke = true; }
                }
            } catch (Exception ignore) { }
        }
        br.close();
        return sb.toString();
    }

    // ------------------------------------------------------------------ acting

    private void runPlan(JSONArray raw) {
        final JSONArray plan = new JSONArray();
        for (int i = 0; i < raw.length() && i < 12; i++) { try { plan.put(raw.get(i)); } catch (Exception e) { } }
        if (!sp.getBoolean("enabled", false)) { show("Phone control is off. Open CORE and send /phone to turn it on."); return; }
        if (PhoneControlService.instance == null) { show("Switch on the CORE accessibility service first (send /phone in the app)."); return; }
        boolean confirm = false;
        for (int i = 0; i < plan.length(); i++) {
            JSONObject a = plan.optJSONObject(i);
            if (a == null || !PhoneBridge.isSafe(a.optString("do"))) confirm = true;
        }
        if (!confirm || sp.getBoolean("auto", false)) { execute(plan); return; }
        final String summary = PhoneBridge.describe(plan);
        runOnUiThread(new Runnable() {
            public void run() {
                if (isFinishing()) return;
                new AlertDialog.Builder(AssistActivity.this)
                        .setTitle("Approve?")
                        .setMessage(summary)
                        .setCancelable(false)
                        .setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { execute(plan); }
                        })
                        .setNegativeButton("Deny", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { show("Cancelled."); }
                        })
                        .show();
            }
        });
    }

    /**
     * Voice "unlock": asks Android to dismiss the lock screen. With no lock or a plain swipe lock the phone opens.
     * With a PIN/pattern/fingerprint/face lock Android shows its own prompt and the user authenticates themselves.
     * Apps cannot bypass a secure lock, and CORE never stores or types the PIN.
     */
    private void unlockPhone() {
        runOnUiThread(new Runnable() {
            public void run() {
                KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                if (km == null || !km.isKeyguardLocked()) { show("Already unlocked."); speak("Already unlocked."); return; }
                if (Build.VERSION.SDK_INT < 26) { show("Swipe to unlock. This Android version can\u2019t do it for you."); return; }
                title.setText("Unlocking\u2026");
                km.requestDismissKeyguard(AssistActivity.this, new KeyguardManager.KeyguardDismissCallback() {
                    @Override public void onDismissSucceeded() { speak("Unlocked."); finish(); }
                    @Override public void onDismissCancelled() { show("Still locked."); }
                    @Override public void onDismissError() { show("I couldn\u2019t open the unlock screen."); }
                });
            }
        });
    }

    /** Makes the user unlock with their own face/fingerprint/PIN first if the phone is locked. CORE never handles the PIN. */
    private void execute(final JSONArray acts) {
        runOnUiThread(new Runnable() {
            public void run() {
                KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                if (km == null || !km.isKeyguardLocked()) { executeNow(acts); return; }
                if (Build.VERSION.SDK_INT >= 26) {
                    title.setText("Unlock to continue");
                    km.requestDismissKeyguard(AssistActivity.this, new KeyguardManager.KeyguardDismissCallback() {
                        @Override public void onDismissSucceeded() { executeNow(acts); }
                        @Override public void onDismissCancelled() { show("Still locked, so I stopped."); }
                        @Override public void onDismissError() { show("I couldn\u2019t open the unlock screen."); }
                    });
                } else {
                    show("Unlock your phone, then ask again.");
                }
            }
        });
    }

    private void executeNow(final JSONArray acts) {
        // close the card first so taps, typing and reading hit the app underneath, not this overlay
        runOnUiThread(new Runnable() { public void run() { finish(); } });
        final Context app = getApplicationContext();
        new Thread(new Runnable() {
            public void run() {
                boolean ok = true;
                String err = null, readText = null;
                try {
                    Thread.sleep(250);
                    for (int i = 0; i < acts.length(); i++) {
                        PhoneControlService s = PhoneControlService.instance;
                        JSONObject a = acts.optJSONObject(i);
                        if (s == null || a == null) { ok = false; err = "the service stopped"; break; }
                        JSONObject r = PhoneBridge.exec(s, a);
                        if (!r.optBoolean("ok")) { ok = false; err = r.optString("error", a.optString("do") + " failed"); break; }
                        if (r.has("text")) readText = r.optString("text");
                        if (i < acts.length() - 1 && !"wait".equals(a.optString("do"))) Thread.sleep(250);
                    }
                } catch (Exception e) { ok = false; err = String.valueOf(e.getMessage()); }
                if (!ok) tell(app, "Couldn\u2019t finish: " + err);
                else if (readText != null && readText.length() > 0) tell(app, readText);
            }
        }).start();
    }

    // ------------------------------------------------------------------ voice out (static so it keeps talking after the card closes)

    private static void initTts(Context app) {
        if (TTS != null) return;
        TTS = new TextToSpeech(app, new TextToSpeech.OnInitListener() {
            public void onInit(int st) { TTS_OK = (st == TextToSpeech.SUCCESS); }
        });
    }

    /** Lets AgentRunner talk through the same voice. */
    static void say(Context c, String t) { initTts(c.getApplicationContext()); speak(t); }

    private static void speak(String t) {
        if (TTS == null || !TTS_OK || t == null || t.length() == 0) return;
        try { TTS.speak(t.length() > 400 ? t.substring(0, 400) : t, TextToSpeech.QUEUE_ADD, null, "core"); } catch (Exception e) { }
    }

    private static void tell(final Context app, final String msg) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            public void run() {
                try { Toast.makeText(app, msg.length() > 300 ? msg.substring(0, 300) : msg, Toast.LENGTH_LONG).show(); } catch (Exception e) { }
            }
        });
        speak(msg);
    }
}
