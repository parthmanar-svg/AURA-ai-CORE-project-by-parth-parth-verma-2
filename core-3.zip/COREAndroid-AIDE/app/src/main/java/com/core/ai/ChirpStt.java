package com.core.ai;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/** Optional Chirp speech-to-text: records the mic, sends it to the worker (/v1/stt), returns all alternates. */
final class ChirpStt {
    interface Callback { void onResult(ArrayList<String> alts); void onError(String msg); }

    private static volatile boolean running = false;
    private static volatile boolean stopFlag = false;

    private ChirpStt() { }

    static boolean configured(Context c) {
        SharedPreferences sp = c.getSharedPreferences("core_phone", Context.MODE_PRIVATE);
        return sp.getString("cloud_url", "").length() > 0 && sp.getString("cloud_token", "").length() > 0;
    }

    static boolean preferred(Context c) {
        return "chirp".equals(c.getSharedPreferences("core_phone", Context.MODE_PRIVATE).getString("stt_engine", "android"));
    }

    static void stop() { stopFlag = true; }

    static void listen(final Context ctx, final String lang, final Callback cb) {
        if (running) { cb.onError("Recognizer busy, try again"); return; }
        running = true; stopFlag = false;
        final Handler main = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() {
            public void run() {
                String err = null; ArrayList<String> out = null;
                try {
                    byte[] pcm = record();
                    if (pcm == null || pcm.length < 8000) err = "Didn't catch that, try again";
                    else out = send(ctx, lang, wav(pcm));
                    if (err == null && (out == null || out.size() == 0)) err = "Didn't catch that, try again";
                } catch (Throwable t) { err = "Chirp: " + t.getMessage(); }
                running = false;
                final String e = err; final ArrayList<String> o = out;
                main.post(new Runnable() { public void run() { if (e != null) cb.onError(e); else cb.onResult(o); } });
            }
        }).start();
    }

    /** 16 kHz mono PCM16. Stops after ~1.1 s of silence once speech began, on stop(), or at 15 s. */
    private static byte[] record() {
        int rate = 16000;
        int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        AudioRecord ar = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 8192));
        if (ar.getState() != AudioRecord.STATE_INITIALIZED) { ar.release(); return null; }
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        short[] buf = new short[1600];   // 100 ms
        boolean spoke = false; int quiet = 0, ticks = 0;
        ar.startRecording();
        try {
            while (!stopFlag && ticks < 150) {
                int n = ar.read(buf, 0, buf.length);
                if (n <= 0) break;
                long sum = 0;
                for (int i = 0; i < n; i++) { sum += Math.abs(buf[i]); bo.write(buf[i] & 0xff); bo.write((buf[i] >> 8) & 0xff); }
                long avg = sum / n;
                ticks++;
                if (avg > 900) { spoke = true; quiet = 0; } else if (spoke) quiet++;
                if (!spoke && ticks > 60) break;   // 6 s of nothing
                if (spoke && quiet >= 11) break;
            }
        } finally { try { ar.stop(); } catch (Exception e) { } ar.release(); }
        return spoke ? bo.toByteArray() : null;
    }

    private static byte[] wav(byte[] pcm) {
        int n = pcm.length, rate = 16000;
        byte[] h = new byte[44];
        put(h, 0, "RIFF"); le(h, 4, n + 36); put(h, 8, "WAVE"); put(h, 12, "fmt "); le(h, 16, 16);
        h[20] = 1; h[22] = 1; le(h, 24, rate); le(h, 28, rate * 2); h[32] = 2; h[34] = 16; put(h, 36, "data"); le(h, 40, n);
        byte[] o = new byte[44 + n];
        System.arraycopy(h, 0, o, 0, 44); System.arraycopy(pcm, 0, o, 44, n);
        return o;
    }
    private static void put(byte[] b, int o, String s) { for (int i = 0; i < s.length(); i++) b[o + i] = (byte) s.charAt(i); }
    private static void le(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24); }

    private static ArrayList<String> send(Context ctx, String lang, byte[] wav) throws Exception {
        SharedPreferences sp = ctx.getSharedPreferences("core_phone", Context.MODE_PRIVATE);
        JSONObject body = new JSONObject().put("audio", Base64.encodeToString(wav, Base64.NO_WRAP)).put("lang", lang == null ? "en-US" : lang);
        HttpURLConnection c = (HttpURLConnection) new URL(sp.getString("cloud_url", "") + "/v1/stt").openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(30000);
        c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("Authorization", "Bearer " + sp.getString("cloud_token", ""));
        OutputStream os = c.getOutputStream();
        os.write(body.toString().getBytes("UTF-8")); os.close();
        if (c.getResponseCode() != 200) throw new java.io.IOException("Chirp route error " + c.getResponseCode());
        java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder(); String ln;
        while ((ln = br.readLine()) != null) sb.append(ln);
        br.close();
        JSONArray a = new JSONObject(sb.toString()).optJSONArray("alts");
        ArrayList<String> out = new ArrayList<String>();
        if (a != null) for (int i = 0; i < a.length(); i++) if (a.optString(i).trim().length() > 0) out.add(a.optString(i).trim());
        return out;
    }
}
