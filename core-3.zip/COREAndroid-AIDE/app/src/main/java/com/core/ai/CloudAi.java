package com.core.ai;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Optional Gemini chat through the CORE Cloud worker (/v1/gemini). */
final class CloudAi {
    private CloudAi() { }

    static boolean geminiPreferred(Context c) {
        SharedPreferences sp = c.getSharedPreferences("core_phone", Context.MODE_PRIVATE);
        return "gemini".equals(sp.getString("ai_provider", "default"));
    }

    /** Non-streaming Gemini reply. messages = OpenAI-style [{role,content}]. */
    static String gemini(String base, String tok, JSONArray msgs, int maxTokens) throws Exception {
        JSONObject body = new JSONObject().put("messages", msgs).put("max_tokens", maxTokens);
        HttpURLConnection c = (HttpURLConnection) new URL(base + "/v1/gemini").openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(60000);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("Authorization", "Bearer " + tok);
        OutputStream os = c.getOutputStream();
        os.write(body.toString().getBytes("UTF-8"));
        os.close();
        if (c.getResponseCode() != 200) throw new java.io.IOException("Gemini route error " + c.getResponseCode());
        java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String ln;
        while ((ln = br.readLine()) != null) sb.append(ln);
        br.close();
        return new JSONObject(sb.toString()).optString("text", "");
    }
}
