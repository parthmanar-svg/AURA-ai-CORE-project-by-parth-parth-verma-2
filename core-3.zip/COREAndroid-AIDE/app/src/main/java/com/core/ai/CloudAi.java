package com.core.ai;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Hosted Gemini client: can use the existing CORE worker or a user-owned API key directly. */
final class CloudAi {
    private CloudAi() { }

    static boolean geminiPreferred(Context c) {
        SharedPreferences sp = c.getSharedPreferences("core_phone", Context.MODE_PRIVATE);
        return "gemini".equals(sp.getString("ai_provider", "default"));
    }

    /** Direct hosted Gemini API call. The key is stored in Android private preferences, not web localStorage. */
    static String geminiDirect(String apiKey, JSONArray msgs, int maxTokens) throws Exception {
        String system = "";
        JSONArray contents = new JSONArray();
        for (int i = 0; i < msgs.length(); i++) {
            JSONObject m = msgs.optJSONObject(i);
            if (m == null) continue;
            String role = m.optString("role", "user");
            String content = m.optString("content", "");
            if ("system".equals(role)) { system = content; continue; }
            contents.put(new JSONObject()
                    .put("role", "assistant".equals(role) ? "model" : "user")
                    .put("parts", new JSONArray().put(new JSONObject().put("text", content))));
        }
        JSONObject body = new JSONObject().put("contents", contents)
                .put("generationConfig", new JSONObject().put("maxOutputTokens", maxTokens));
        if (system.length() > 0) body.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", system))));
        String endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent";
        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(60000);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("x-goog-api-key", apiKey);
        OutputStream os = c.getOutputStream();
        os.write(body.toString().getBytes("UTF-8"));
        os.close();
        int code = c.getResponseCode();
        java.io.InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(stream, "UTF-8"));
        StringBuilder sb = new StringBuilder(); String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close(); c.disconnect();
        JSONObject result = new JSONObject(sb.toString());
        if (code < 200 || code >= 300) {
            String detail = result.optJSONObject("error") == null ? "HTTP " + code : result.optJSONObject("error").optString("message", "HTTP " + code);
            throw new java.io.IOException("Gemini API: " + detail);
        }
        JSONArray candidates = result.optJSONArray("candidates");
        if (candidates == null || candidates.length() == 0) throw new java.io.IOException("Gemini returned no answer (possibly blocked by safety settings).");
        JSONObject content = candidates.optJSONObject(0).optJSONObject("content");
        JSONArray parts = content == null ? null : content.optJSONArray("parts");
        StringBuilder answer = new StringBuilder();
        if (parts != null) for (int i = 0; i < parts.length(); i++) {
            JSONObject part = parts.optJSONObject(i);
            if (part != null) answer.append(part.optString("text", ""));
        }
        if (answer.length() == 0) throw new java.io.IOException("Gemini returned an empty answer.");
        return answer.toString();
    }

    /** Non-streaming Gemini reply. messages = OpenAI-style [{role,content}]. */
    static String gemini(String base, String tok, JSONArray msgs, int maxTokens) throws Exception {
        JSONObject body = new JSONObject().put("messages", msgs).put("max_tokens", maxTokens);
        HttpURLConnection c = (HttpURLConnection) new URL(base + "/v1/gemini").openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(60000);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("Authorization", "Bearer " + tok);
        OutputStream os = c.getOutputStream();
        os.write(body.toString().getBytes("UTF-8"));
        os.close();
        if (c.getResponseCode() != 200) throw new java.io.IOException("Gemini route error " + c.getResponseCode());
        java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String ln;
        while ((ln = br.readLine()) != null) sb.append(ln);
        br.close();
        return new JSONObject(sb.toString()).optString("text", "");
    }
}
