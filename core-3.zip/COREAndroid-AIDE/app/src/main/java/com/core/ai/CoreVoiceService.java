package com.core.ai;

import android.service.voice.VoiceInteractionService;

/** Makes CORE selectable as the phone's digital assistant (hold Home / power button). */
public class CoreVoiceService extends VoiceInteractionService {
    static volatile CoreVoiceService instance;

    @Override public void onReady() { super.onReady(); instance = this; AssistActivity.warm(getApplicationContext()); }
    @Override public void onShutdown() { instance = null; super.onShutdown(); }
}
