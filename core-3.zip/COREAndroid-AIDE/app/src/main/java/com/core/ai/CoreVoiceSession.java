package com.core.ai;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.service.voice.VoiceInteractionSession;

/** Fires when the user holds Home: opens the listening card, then ends the session. */
public class CoreVoiceSession extends VoiceInteractionSession {
    private static final String TAG = "COREVoiceSession";
    public CoreVoiceSession(Context context) { super(context); }

    @Override
    public void onShow(Bundle args, int showFlags) {
        super.onShow(args, showFlags);
        try {
            Intent i = new Intent(getContext(), AssistActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            String cmd = args == null ? null : args.getString("cmd");
            i.putExtra("cmd", cmd == null ? "" : cmd);
            getContext().startActivity(i);
            // Close the voice session only after Android accepted the Activity launch.
            finish();
        } catch (Exception e) {
            // The old code swallowed this exception and always finished the session,
            // leaving the user with no assistant card and no clue why.
            Log.e(TAG, "Failed to launch CORE assistant card", e);
        }
    }
}
