package com.core.ai;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Spoken commands that need no model and no network. Returns a one-action plan, or null if it isn't a quick command. */
final class FastCommands {
    private FastCommands() { }

    private static JSONArray one(String d, String k, String v) {
        try {
            JSONObject o = new JSONObject();
            o.put("do", d);
            if (k != null) o.put(k, v);
            return new JSONArray().put(o);
        } catch (Exception e) { return null; }
    }

    static JSONArray parse(String said) {
        if (said == null) return null;
        String s = said.toLowerCase(Locale.ROOT).trim().replaceAll("[.!?,]+$", "");
        s = s.replaceFirst("^(please |hey core[ ,]*|ok core[ ,]*|core[ ,]*)", "").trim();
        // Common spoken Hindi/Hinglish equivalents. Keep this deterministic and offline.
        s = s.replaceAll("\\b( kholo| khol do| kholna| chalao| chala do)$", "").trim();
        if (s.matches("(ghar|home|home screen|home par jao|ghar chalo|home jao|home pe jao|main screen|मुख्य स्क्रीन|होम पर जाओ)")) return one("home", null, null);
        if (s.matches("(peeche jao|pichhe jao|wapas jao|back jao|back|go back|वापस जाओ|पीछे जाओ)")) return one("back", null, null);
        if (s.matches("(recent apps|recents|app switcher|show recent apps|recent kholo|recent apps kholo|खुले हुए ऐप दिखाओ)")) return one("recents", null, null);
        if (s.matches("(notifications|notification kholo|notifications kholo|notification dikhao|सूचनाएं दिखाओ|नोटिफिकेशन खोलो)")) return one("notifications", null, null);
        if (s.matches("(quick settings|quick settings kholo|control panel kholo|क्विक सेटिंग खोलो)")) return one("quick", null, null);
        Matcher m;
        m = Pattern.compile("^(?:youtube|yt|यूट्यूब)$").matcher(s);
        if (m.matches()) return one("open", "app", "YouTube");
        m = Pattern.compile("^(?:whatsapp|व्हाट्सएप|व्हाट्स ऐप)$").matcher(s);
        if (m.matches()) return one("open", "app", "WhatsApp");
        m = Pattern.compile("^(?:instagram|insta|इंस्टाग्राम)$").matcher(s);
        if (m.matches()) return one("open", "app", "Instagram");
        m = Pattern.compile("^(?:chrome|क्रोम)$").matcher(s);
        if (m.matches()) return one("open", "app", "Chrome");
        m = Pattern.compile("^(?:settings|setting|सेटिंग|सेटिंग्स)$").matcher(s);
        if (m.matches()) return one("settings", null, null);
        m = Pattern.compile("^(?:volume|आवाज़|आवाज|वॉल्यूम)\\s*(up|down|बढ़ाओ|बढ़ाओ|कम करो|तेज|धीमा)$").matcher(s);
        if (m.find()) return one("volume", "dir", (m.group(1).equals("down") || m.group(1).equals("कम करो") || m.group(1).equals("धीमा")) ? "down" : "up");
        m = Pattern.compile("^(?:scroll|स्क्रॉल)\\s*(up|down|ऊपर|नीचे)$").matcher(s);
        if (m.find()) return one("scroll", "dir", (m.group(1).equals("down") || m.group(1).equals("नीचे")) ? "down" : "up");
        if (s.matches("unlock|unlock (my |the )?(phone|screen|device)|wake up|open (my |the )?(phone|screen)")) return one("unlock", null, null);
        if (s.matches("(go )?(to )?(the )?home( screen)?")) return one("home", null, null);
        if (s.matches("go back|back")) return one("back", null, null);
        if (s.matches("recent apps|recents|app switcher|show recent apps")) return one("recents", null, null);
        if (s.matches("(show |open )?notifications|pull down notifications")) return one("notifications", null, null);
        if (s.matches("(open )?quick settings")) return one("quick", null, null);
        m = Pattern.compile("^scroll (up|down)$").matcher(s);
        if (m.find()) return one("scroll", "dir", m.group(1));
        m = Pattern.compile("^(?:turn )?(?:the )?volume (up|down)$").matcher(s);
        if (m.find()) return one("volume", "dir", m.group(1));
        m = Pattern.compile("^(?:open|launch|start| kholo|kholo|khol do|chalao|open karo| खोलो|खोल दो|चालू करो|चलाओ)\\s+(.{1,40})$").matcher(s);
        if (m.find()) return one("open", "app", m.group(1));
        m = Pattern.compile("^(?:open|kholo|khol do|chalao|चलाओ|खोलो)\\s+(.{1,40})$").matcher(s);
        if (m.find()) return one("open", "app", m.group(1).trim());
        m = Pattern.compile("^(?:google|search for|search|search karo|dhundo|dhoondo|खोजो|सर्च करो)\\s+(.{1,120})$").matcher(s);
        if (m.find()) { try { return one("url", "url", "https://www.google.com/search?q=" + URLEncoder.encode(m.group(1), "UTF-8")); } catch (Exception e) { return null; } }
        m = Pattern.compile("^call ([+\\d][\\d\\s()-]{2,20})$").matcher(s);
        if (m.find()) return one("dial", "number", m.group(1).replaceAll("\\s", ""));
        m = Pattern.compile("^(?:google|search for|search) (.{1,120})$").matcher(s);
        if (m.find()) {
            try { return one("url", "url", "https://www.google.com/search?q=" + URLEncoder.encode(m.group(1), "UTF-8")); } catch (Exception e) { return null; }
        }
        return null;
    }
}
