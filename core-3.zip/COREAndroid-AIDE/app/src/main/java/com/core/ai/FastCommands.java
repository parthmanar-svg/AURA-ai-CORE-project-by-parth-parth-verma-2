package com.core.ai;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Spoken commands that need no model and no network. Returns a one-action plan, or null if it isn't a quick command. */
final class FastCommands {
    private FastCommands() { }

    private static JSONArray one(String d, String k, String v) {
        try {
            JSONObject o = new JSONObject();
            o.put("do", d);
            if (k != null) o.put(k, v);
            return new JSONArray().put(o);
        } catch (Exception e) { return null; }
    }

    static JSONArray parse(String said) {
        if (said == null) return null;
        String s = said.toLowerCase(Locale.US).trim().replaceAll("[.!?,]+$", "");
        s = s.replaceFirst("^(please |hey core |ok core |core )", "").trim();
        Matcher m;
        if (s.matches("unlock|unlock (my |the )?(phone|screen|device)|wake up|open (my |the )?(phone|screen)")) return one("unlock", null, null);
        if (s.matches("(go )?(to )?(the )?home( screen)?")) return one("home", null, null);
        if (s.matches("go back|back")) return one("back", null, null);
        if (s.matches("recent apps|recents|app switcher|show recent apps")) return one("recents", null, null);
        if (s.matches("(show |open )?notifications|pull down notifications")) return one("notifications", null, null);
        if (s.matches("(open )?quick settings")) return one("quick", null, null);
        m = Pattern.compile("^scroll (up|down)$").matcher(s);
        if (m.find()) return one("scroll", "dir", m.group(1));
        m = Pattern.compile("^(?:turn )?(?:the )?volume (up|down)$").matcher(s);
        if (m.find()) return one("volume", "dir", m.group(1));
        m = Pattern.compile("^(?:open|launch|start) (.{1,40})$").matcher(s);
        if (m.find()) return one("open", "app", m.group(1));
        m = Pattern.compile("^call ([+\\d][\\d\\s()-]{2,20})$").matcher(s);
        if (m.find()) return one("dial", "number", m.group(1).replaceAll("\\s", ""));
        m = Pattern.compile("^(?:google|search for|search) (.{1,120})$").matcher(s);
        if (m.find()) {
            try { return one("url", "url", "https://www.google.com/search?q=" + URLEncoder.encode(m.group(1), "UTF-8")); } catch (Exception e) { return null; }
        }
        return null;
    }
}
