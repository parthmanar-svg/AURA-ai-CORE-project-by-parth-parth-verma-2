package com.core.ai;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Spoken commands that need no model and no network.
 * Returns a plan (one or several actions), or null if it isn't a quick command.
 * Chains work offline: "open YouTube then scroll down and go home".
 */
final class FastCommands {
    private FastCommands() { }

    private static JSONArray one(String d, String k, String v) {
        try {
            JSONObject o = new JSONObject();
            o.put("do", d);
            if (k != null) o.put(k, v);
            return new JSONArray().put(o);
        } catch (Exception e) { return null; }
    }

    private static JSONArray flag(String d, String k, boolean v) {
        try { return new JSONArray().put(new JSONObject().put("do", d).put(k, v)); } catch (Exception e) { return null; }
    }

    private static JSONObject wait(int ms) {
        try { return new JSONObject().put("do", "wait").put("ms", ms); } catch (Exception e) { return null; }
    }

    private static final String[] VERBS = {"open", "scroll", "screenshot", "volume", "unlock", "launch", "search", "google", "notifications",
            "flashlight", "torch", "pause", "wait", "call", "home", "back", "play", "lock", "recents", "start", "settings"};

    private static int dist(String x, String y) {
        int[] prev = new int[y.length() + 1], cur = new int[y.length() + 1];
        for (int j = 0; j <= y.length(); j++) prev[j] = j;
        for (int i = 1; i <= x.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= y.length(); j++) {
                int c = x.charAt(i - 1) == y.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + c);
            }
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[y.length()];
    }

    /** Fixes a mistyped or misheard first word ("opn", "scrol", "screnshot") by snapping it to the closest known verb. */
    private static String fixTypo(String s) {
        int sp = s.indexOf(' ');
        String w = sp < 0 ? s : s.substring(0, sp), rest = sp < 0 ? "" : s.substring(sp);
        if (w.length() < 3) return s;
        for (int i = 0; i < VERBS.length; i++) if (VERBS[i].equals(w)) return s;
        String best = null; int bd = 2;
        for (int i = 0; i < VERBS.length; i++) {
            if (Math.abs(VERBS[i].length() - w.length()) > 1) continue;
            int d = dist(w, VERBS[i]);
            if (d < bd) { bd = d; best = VERBS[i]; }
        }
        return best == null ? s : best + rest;
    }

    private static int num(String t) {
        if (t == null) return 1;
        String[] w = {"one", "two", "three", "four", "five"};
        for (int i = 0; i < w.length; i++) if (w[i].equals(t)) return i + 1;
        try { return Integer.parseInt(t); } catch (Exception e) { return 1; }
    }

    static String alias(String app) {
        String a = app.trim().replaceFirst("^(?:the |my )", "").replaceFirst(" app$", "").trim();
        if (a.matches("yt|youtube app|you tube|utube")) return "youtube";
        if (a.matches("insta|ig|instagram app")) return "instagram";
        if (a.matches("fb|face book")) return "facebook";
        if (a.matches("wa|whats app|whatsap|watsapp")) return "whatsapp";
        if (a.matches("gmaps|google maps|map")) return "maps";
        if (a.matches("tt|tik tok")) return "tiktok";
        if (a.matches("snap")) return "snapchat";
        if (a.matches("g mail|google mail|mail")) return "gmail";
        if (a.matches("pics|photos|gallery|pictures")) return "photos";
        if (a.matches("cam")) return "camera";
        if (a.matches("calc")) return "calculator";
        return a;
    }

    static String norm(String said) {
        String s = said.toLowerCase(Locale.US).trim();
        s = s.replaceFirst("^(?:(?:hey|ok|okay|yo)\\s+(?:core|google|assistant)|core|assistant)\\b[ ,]*", "");
        s = s.replaceAll("\\b(?:please|pls|plz|just|now|right now|quickly|real quick|asap|for me|can you|could you|would you|will you|i want you to|i need you to|i want to|i wanna|i need to|go ahead and|lets|let's|you should|try to|kindly)\\b", " ");
        s = s.replaceAll("\\s+", " ").replaceAll("^[ ,]+|[ ,.!?;]+$", "");
        s = s.replaceFirst("^(?:pull up|bring up|fire up|boot up|boot|run|load|go to|goto|switch to|put on)\\s+", "open ");
        s = fixTypo(s);
        s = s.replaceAll("^(?:launch|start)\\s+", "open ");
        return s.trim();
    }

    /** One or two bare words ("youtube", "whatsapp") with no cloud to ask: just try opening it as an app. */
    static JSONArray bareApp(String said) {
        if (said == null) return null;
        String s = norm(said);
        if (!s.matches("^[a-z0-9][a-z0-9 .+&-]{1,24}$")) return null;
        if (s.split(" ").length > 3) return null;
        if (s.matches("^(?:hi|hello|hey|yo|thanks|thank you|thx|yes|no|nope|ok|okay|sure|test|help|stop|what|who|why|how|when|where|lol|wow)$")) return null;
        return one("open", "app", alias(s));
    }

    static JSONArray parse(String said) {
        if (said == null) return null;
        String s = norm(said);
        JSONArray a = single(s);
        return a != null ? a : chain(s);
    }

    /** "open X then scroll down and go home": every part must be a quick command, otherwise the whole thing goes to the agent. */
    private static JSONArray chain(String s) {
        String[] parts = s.split("\\s*,?\\s*\\b(?:and then|then|after that|afterwards|and)\\b\\s*|\\s*,\\s*");
        if (parts.length < 2 || parts.length > 6) return null;
        JSONArray out = new JSONArray();
        try {
            for (int i = 0; i < parts.length; i++) {
                String p = norm(parts[i]);
                if (p.length() == 0) return null;
                // "open YouTube and search lo-fi" means search INSIDE the app, which needs the screen: leave it to the agent
                if (i > 0 && p.matches("^(?:google|search).*")) return null;
                JSONArray a = single(p);
                if (a == null || a.length() == 0) return null;
                String d = a.getJSONObject(0).optString("do");
                if ("unlock".equals(d)) return null;
                for (int j = 0; j < a.length(); j++) out.put(a.get(j));
                if (i < parts.length - 1) {
                    if ("open".equals(d) || "url".equals(d)) out.put(wait(1400));
                    else if ("home".equals(d) || "recents".equals(d) || "notifications".equals(d) || "quick".equals(d)) out.put(wait(500));
                }
            }
        } catch (Exception e) { return null; }
        return out.length() > 0 && out.length() <= 14 ? out : null;
    }

    private static JSONArray single(String s) {
        Matcher m;
        if (s.matches("unlock|unlock (my |the )?(phone|screen|device)|wake up|open (my |the )?(phone|screen)")) return one("unlock", null, null);
        if (s.matches("(go )?(to )?(the )?home( screen)?")) return one("home", null, null);
        if (s.matches("go back|back")) return one("back", null, null);
        if (s.matches("recent apps|recents|app switcher|show recent apps")) return one("recents", null, null);
        if (s.matches("(show |open )?notifications|pull down notifications")) return one("notifications", null, null);
        if (s.matches("(open )?quick settings")) return one("quick", null, null);
        if (s.matches("(?:take (?:a )?)?screenshot|screen ?shot")) return one("screenshot", null, null);
        if (s.matches("lock(?: the)?(?: phone| screen| device)?")) return one("lock", null, null);
        if (s.matches("(?:read(?: the| my| this)?(?: screen| page)?|what(?:s| is) on (?:the |my )?screen)")) return one("read", null, null);
        if (s.matches("(?:louder|volume higher|vol up|turn it up|turn up(?: the)?(?: volume)?|raise(?: the)? volume|increase(?: the)? volume|volume up)")) return one("volume", "dir", "up");
        if (s.matches("(?:quieter|softer|vol down|turn it down|turn down(?: the)?(?: volume)?|lower(?: the)? volume|decrease(?: the)? volume|too loud|volume down)")) return one("volume", "dir", "down");
        if (s.matches("(?:mute|silence|silent)(?: it| phone| the phone)?")) {
            JSONArray out = new JSONArray();
            try { for (int i = 0; i < 8; i++) { out.put(new JSONObject().put("do", "volume").put("dir", "down")); out.put(wait(80)); } } catch (Exception e) { return null; }
            return out;
        }
        if (s.matches("(?:max|full|maximum) volume")) {
            JSONArray out = new JSONArray();
            try { for (int i = 0; i < 10; i++) { out.put(new JSONObject().put("do", "volume").put("dir", "up")); out.put(wait(80)); } } catch (Exception e) { return null; }
            return out;
        }
        m = Pattern.compile("^(?:scroll |go |page |swipe )?(up|down|dwn|dwon|donw|upp)(?: (\\d|one|two|three|four|five) times?)?$").matcher(s);
        if (m.find()) {
            int n = Math.max(1, Math.min(5, num(m.group(2))));
            String dir = m.group(1).startsWith("d") ? "down" : "up";
            JSONArray out = new JSONArray();
            try {
                for (int i = 0; i < n; i++) {
                    out.put(new JSONObject().put("do", "scroll").put("dir", dir));
                    if (i < n - 1) out.put(wait(350));
                }
            } catch (Exception e) { return null; }
            return out;
        }
        m = Pattern.compile("^(?:turn )?(?:the )?volume (up|down)$").matcher(s);
        if (m.find()) return one("volume", "dir", m.group(1));
        m = Pattern.compile("^wait (\\d{1,2}) ?(?:seconds?|secs?|s)$").matcher(s);
        if (m.find()) { JSONArray w = new JSONArray(); w.put(wait(Integer.parseInt(m.group(1)) * 1000)); return w; }
        m = Pattern.compile("^(?:turn )?(on|off)(?: the)? (?:torch|flashlight|flash light)$").matcher(s);
        if (m.find()) return flag("torch", "on", "on".equals(m.group(1)));
        m = Pattern.compile("^(?:torch|flashlight)(?: (on|off))?$").matcher(s);
        if (m.find()) return flag("torch", "on", !"off".equals(m.group(1)));
        if (s.matches("(?:play|resume)(?: the)?(?: music| song| media)?")) return one("media", "key", "play");
        if (s.matches("pause(?: the)?(?: music| song| media)?")) return one("media", "key", "pause");
        if (s.matches("(?:next|skip)(?: song| track)?")) return one("media", "key", "next");
        if (s.matches("(?:previous|prev)(?: song| track)?")) return one("media", "key", "prev");
        m = Pattern.compile("^(?:open )?(wifi|bluetooth|display|sound|battery|location|airplane) settings$").matcher(s);
        if (m.find()) return one("settings", "page", m.group(1));
        m = Pattern.compile("^(?:open|launch|start) (.{1,40})$").matcher(s);
        if (m.find()) return one("open", "app", alias(m.group(1)));
        m = Pattern.compile("^call ([+\\d][\\d\\s()-]{2,20})$").matcher(s);
        if (m.find()) return one("dial", "number", m.group(1).replaceAll("\\s", ""));
        m = Pattern.compile("^(?:google|search for|search) (.{1,120})$").matcher(s);
        if (m.find()) {
            try { return one("url", "url", "https://www.google.com/search?q=" + URLEncoder.encode(m.group(1), "UTF-8")); } catch (Exception e) { return null; }
        }
        return null;
    }
}
