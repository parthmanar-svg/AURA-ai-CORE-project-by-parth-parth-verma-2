package com.core.ai;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Loads the bundled CORE web app from /assets through a fake https origin
 * (needed for camera/mic and relative model paths). No AndroidX needed.
 */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/assets/index.html";
    private static final int PERMISSION_REQUEST = 901;

    private WebView webView;
    private PermissionRequest pendingRequest;
    private CoreBridge bridge;
    public static volatile boolean foreground = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        // dark background (no white flash), no overscroll glow
        webView.setBackgroundColor(0xFF03070A);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return serveAsset(request);
            }

            // API 24+
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                return host != null && !host.equals(HOST);
            }

            // API 23 and below
            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                String host = android.net.Uri.parse(url).getHost();
                return host != null && !host.equals(HOST);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            // Puter sign-in opens a popup window; show it in a full-screen dialog
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, android.os.Message resultMsg) {
                final WebView pop = new WebView(MainActivity.this);
                WebSettings ps = pop.getSettings();
                ps.setJavaScriptEnabled(true); ps.setDomStorageEnabled(true);
                ps.setSupportMultipleWindows(true); ps.setJavaScriptCanOpenWindowsAutomatically(true);
                final android.app.Dialog d = new android.app.Dialog(MainActivity.this, android.R.style.Theme_DeviceDefault_NoActionBar);
                d.setContentView(pop);
                pop.setWebViewClient(new WebViewClient());
                pop.setWebChromeClient(new WebChromeClient() {
                    @Override public void onCloseWindow(WebView w) { try { d.dismiss(); } catch (Throwable t) { } }
                });
                d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                    public void onDismiss(android.content.DialogInterface x) { try { pop.destroy(); } catch (Throwable t) { } }
                });
                d.show();
                WebView.WebViewTransport t = (WebView.WebViewTransport) resultMsg.obj;
                t.setWebView(pop); resultMsg.sendToTarget();
                return true;
            }
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    public void run() { handlePermission(request); }
                });
            }
        });

        bridge = new CoreBridge(this, webView);
        webView.addJavascriptInterface(bridge, "CORE_NATIVE");
        webView.addJavascriptInterface(new PhoneBridge(this, webView), "CORE_PHONE_NATIVE");

        webView.loadUrl(START);
    }

    @Override protected void onResume() { super.onResume(); foreground = true; }
    @Override protected void onPause() { foreground = false; super.onPause(); }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (bridge != null) bridge.onPicked(requestCode, resultCode, data);
    }

    private void handlePermission(PermissionRequest request) {
        boolean needCam = false, needMic = false;
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) needCam = true;
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) needMic = true;
        }
        boolean missing = (needCam && !has(Manifest.permission.CAMERA))
                || (needMic && !has(Manifest.permission.RECORD_AUDIO));
        if (missing && Build.VERSION.SDK_INT >= 23) {
            pendingRequest = request;
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST);
            return;
        }
        request.grant(request.getResources());
    }

    private boolean has(String perm) {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == CoreBridge.REQ_MIC && bridge != null) { bridge.onPermission(code, results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED); return; }
        if (code == PERMISSION_REQUEST && pendingRequest != null) {
            boolean all = results.length > 0;
            for (int r : results) if (r != PackageManager.PERMISSION_GRANTED) all = false;
            if (all) pendingRequest.grant(pendingRequest.getResources()); else pendingRequest.deny();
            pendingRequest = null;
        }
    }

    // ---- tiny replacement for WebViewAssetLoader ----
    private static final Map<String, String> MIME = new HashMap<String, String>();
    static {
        MIME.put("html", "text/html");
        MIME.put("js", "application/javascript");
        MIME.put("mjs", "application/javascript");
        MIME.put("css", "text/css");
        MIME.put("json", "application/json");
        MIME.put("webmanifest", "application/manifest+json");
        MIME.put("wasm", "application/wasm");
        MIME.put("tflite", "application/octet-stream");
        MIME.put("png", "image/png");
        MIME.put("jpg", "image/jpeg");
        MIME.put("jpeg", "image/jpeg");
        MIME.put("svg", "image/svg+xml");
        MIME.put("ico", "image/x-icon");
        MIME.put("txt", "text/plain");
    }

    private WebResourceResponse serveAsset(WebResourceRequest request) {
        if (!HOST.equals(request.getUrl().getHost())) return null; // real network
        String path = request.getUrl().getPath();
        if (path == null || !path.startsWith("/assets/")) return notFound();
        String rel = path.substring("/assets/".length());
        if (rel.length() == 0 || rel.contains("..")) rel = "index.html";
        try {
            InputStream in = getAssets().open(rel);
            String ext = "";
            int dot = rel.lastIndexOf('.');
            if (dot >= 0) ext = rel.substring(dot + 1).toLowerCase();
            String mime = MIME.containsKey(ext) ? MIME.get(ext) : "application/octet-stream";
            boolean text = mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json") || mime.contains("manifest");
            WebResourceResponse resp = new WebResourceResponse(mime, text ? "UTF-8" : null, in);
            if (Build.VERSION.SDK_INT >= 21) {
                Map<String, String> h = new HashMap<String, String>();
                h.put("Access-Control-Allow-Origin", "*");
                h.put("Cache-Control", "no-cache");
                resp.setResponseHeaders(h);
            }
            return resp;
        } catch (IOException e) {
            return notFound();
        }
    }

    private WebResourceResponse notFound() {
        WebResourceResponse r = new WebResourceResponse("text/plain", "UTF-8", new java.io.ByteArrayInputStream(new byte[0]));
        if (Build.VERSION.SDK_INT >= 21) r.setStatusCodeAndReasonPhrase(404, "Not Found");
        return r;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (bridge != null) { bridge.destroy(); bridge = null; }
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
