package com.core.ai;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Multi-step tasks with NO model, NO cloud, NO account: understands blunt step lists
 * ("yt lofi then play first result", "open instagram, search cats, like", "tap settings and scroll down")
 * and does them by reading the screen through the accessibility service.
 */
final class OfflineAgent {
    private OfflineAgent() { }

    private static final class Step {
        final String kind; final String arg;
        JSONArray plan;
        Step(String k, String a) { kind = k; arg = a; }
        Step append(String more) { return new Step(kind, arg + " " + more); }
    }

    private static final String APPS = "yt|youtube|instagram|insta|ig|facebook|fb|whatsapp|wa|tiktok|tt|snapchat|spotify|chrome|maps|gmaps|gmail|telegram|twitter|reddit|netflix|photos|play store|camera|calculator";
    private static final String SPLIT = "\\s*,?\\s*\\b(?:and then|then|after that|afterwards|and)\\b\\s*|\\s*,\\s*";

    static boolean canHandle(String goal) { return parse(goal) != null; }

    // ------------------------------------------------------------------ understanding

    private static List<Step> parse(String goal) {
        if (goal == null) return null;
        String s = FastCommands.norm(goal);
        String[] parts = s.split(SPLIT);
        ArrayList<Step> out = new ArrayList<Step>();
        for (int i = 0; i < parts.length && out.size() < 30; i++) {
            String p = FastCommands.norm(parts[i]);
            if (p.length() == 0) continue;
            List<Step> st = parseStep(p);
            if (st == null) {
                // "search cats and dogs": the leftover belongs to the previous search/type text
                if (!out.isEmpty()) {
                    Step last = out.get(out.size() - 1);
                    if ("search".equals(last.kind) || "type".equals(last.kind)) { out.set(out.size() - 1, last.append("and " + p)); continue; }
                }
                return null;
            }
            out.addAll(st);
        }
        return out.isEmpty() ? null : out;
    }

    private static List<Step> parseStep(String p) {
        ArrayList<Step> r = new ArrayList<Step>();
        Matcher m;
        m = Pattern.compile("^open (.+)$").matcher(p);
        if (m.find()) { r.add(new Step("open", FastCommands.alias(m.group(1)))); return r; }

        m = Pattern.compile("^(?:play|watch|listen to|put on) (?:the )?(?:first|top|1st) (?:result|video|one|song|item)$").matcher(p);
        if (m.find()) { r.add(new Step("first", "")); return r; }
        m = Pattern.compile("^(?:(?:play|open|tap) )?(?:the )?(?:first|top|1st) (?:result|video|one|song|item)$").matcher(p);
        if (m.find()) { r.add(new Step("first", "")); return r; }

        m = Pattern.compile("^(?:search|find|look up|lookup|google)(?: for)? (.+?)(?: (?:on|in|at|using) (.+))?$").matcher(p);
        if (m.find()) {
            if (m.group(2) != null) r.add(new Step("open", FastCommands.alias(m.group(2))));
            r.add(new Step("search", m.group(1)));
            return r;
        }
        m = Pattern.compile("^(?:play|watch|listen to|put on) (.+?)(?: (?:on|in|using) (.+))?$").matcher(p);
        if (m.find()) {
            if (m.group(2) != null) r.add(new Step("open", FastCommands.alias(m.group(2))));
            r.add(new Step("search", m.group(1)));
            r.add(new Step("first", ""));
            return r;
        }
        m = Pattern.compile("^(?:tap|click|press|hit|select|choose|touch) (.+)$").matcher(p);
        if (m.find()) { r.add(new Step("tap", m.group(1).replaceFirst("^(?:the |on )", "").replaceFirst(" button$", ""))); return r; }
        m = Pattern.compile("^(?:type|write|enter|input) (.+)$").matcher(p);
        if (m.find()) { r.add(new Step("type", m.group(1))); return r; }
        m = Pattern.compile("^(like|unlike|subscribe|unsubscribe|follow|unfollow|save|share|comment|reply|repost|bookmark)(?: this| the| it)?(?: video| post| reel| channel| page| account| song| short)?$").matcher(p);
        if (m.find()) { r.add(new Step("tap", m.group(1))); return r; }
        m = Pattern.compile("^(" + APPS + ") (.+)$").matcher(p);
        if (m.find()) {
            r.add(new Step("open", FastCommands.alias(m.group(1))));
            r.add(new Step("search", m.group(2)));
            return r;
        }
        JSONArray fast = FastCommands.parse(p);
        if (fast != null) { Step f = new Step("fast", p); f.plan = fast; r.add(f); return r; }
        return null;
    }

    // ------------------------------------------------------------------ doing

    static String run(PhoneControlService svc, String goal) throws Exception {
        List<Step> steps = parse(goal);
        if (steps == null) return "I couldn\u2019t follow that without CORE Cloud. Use short steps, like: open YouTube, search lo-fi, play the first result.";
        Thread.sleep(250);
        for (int i = 0; i < steps.size(); i++) {
            if (AgentRunner.stopped()) return "Stopped.";
            if (PhoneControlService.instance == null) return "The accessibility service stopped.";
            if (svc.isProtectedScreen()) return "Stopped: a banking or password app is on screen.";
            Step st = steps.get(i);
            String label = describe(st);
            AgentRunner.updateNote(svc, goal, "Step " + (i + 1) + "/" + steps.size() + ": " + label);
            String err;
            try { err = exec(svc, st); } catch (Exception e) { err = String.valueOf(e.getMessage()); }
            if (err != null) return "Couldn\u2019t finish at step " + (i + 1) + " (" + label + "): " + err;
            Thread.sleep(450);
        }
        return "Done.";
    }

    private static String describe(Step s) {
        if ("open".equals(s.kind)) return "open " + s.arg;
        if ("search".equals(s.kind)) return "search \u201c" + s.arg + "\u201d";
        if ("first".equals(s.kind)) return "open first result";
        if ("tap".equals(s.kind)) return "press \u201c" + s.arg + "\u201d";
        if ("type".equals(s.kind)) return "type \u201c" + s.arg + "\u201d";
        return s.arg;
    }

    private static String exec(PhoneControlService svc, Step st) throws Exception {
        String k = st.kind;
        if ("open".equals(k)) {
            JSONObject r = PhoneBridge.exec(svc, new JSONObject().put("do", "open").put("app", st.arg));
            if (!r.optBoolean("ok")) return r.optString("error", "couldn\u2019t open " + st.arg);
            Thread.sleep(1700);
            return null;
        }
        if ("fast".equals(k)) {
            for (int i = 0; i < st.plan.length(); i++) {
                JSONObject r = PhoneBridge.exec(svc, st.plan.getJSONObject(i));
                if (!r.optBoolean("ok")) return r.optString("error", "failed");
                if (i < st.plan.length() - 1) Thread.sleep(250);
            }
            return null;
        }
        if ("search".equals(k)) return search(svc, st.arg);
        if ("first".equals(k)) {
            for (int a = 0; a < 3; a++) {
                svc.dumpUi(90);
                int id = svc.firstResultId();
                if (id >= 0 && svc.tapId(id)) { Thread.sleep(1500); return null; }
                Thread.sleep(800);
            }
            return "no result to open";
        }
        if ("tap".equals(k)) return tap(svc, st.arg);
        if ("type".equals(k)) {
            if (svc.typeText(st.arg)) return null;
            svc.dumpUi(80);
            int ed = svc.findEditable(null);
            if (ed >= 0) { svc.tapId(ed); Thread.sleep(350); if (svc.typeText(st.arg)) return null; }
            return "no text box to type in";
        }
        return "unknown step";
    }

    private static String search(PhoneControlService svc, String q) throws Exception {
        for (int attempt = 0; attempt < 4; attempt++) {
            svc.dumpUi(90);
            int ed = svc.findEditable("search");
            if (ed < 0) {
                int btn = svc.findClickable("search");
                if (btn >= 0) { svc.tapId(btn); Thread.sleep(900); svc.dumpUi(90); ed = svc.findEditable("search"); }
            }
            if (ed >= 0) {
                svc.tapId(ed);
                Thread.sleep(450);
                if (!svc.typeText(q)) { Thread.sleep(350); continue; }
                Thread.sleep(600);
                if (!svc.imeEnter()) {
                    svc.dumpUi(90);
                    int sug = svc.findSuggestion(q);
                    if (sug >= 0) svc.tapId(sug);
                    else {
                        int b = svc.findClickable("search");
                        if (b >= 0) svc.tapId(b);
                    }
                }
                Thread.sleep(1900);
                return null;
            }
            Thread.sleep(900);
        }
        return "couldn\u2019t find a search box here";
    }

    private static String tap(PhoneControlService svc, String what) throws Exception {
        for (int attempt = 0; attempt < 5; attempt++) {
            svc.dumpUi(100);
            int id = svc.findClickable(what);
            if (id >= 0) {
                String lab = svc.labelOf(id);
                if (AgentRunner.DENY.matcher(lab).find()) return "refused to press \u201c" + lab + "\u201d (looks like money or a destructive action)";
                if (svc.tapId(id)) { Thread.sleep(700); return null; }
            }
            if (attempt == 0 && svc.clickText(what)) { Thread.sleep(700); return null; }
            svc.scroll(true);
            Thread.sleep(650);
        }
        return "couldn\u2019t find \u201c" + what + "\u201d on screen";
    }
}
