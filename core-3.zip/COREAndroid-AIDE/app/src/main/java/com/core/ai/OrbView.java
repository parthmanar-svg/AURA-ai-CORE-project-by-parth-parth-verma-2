package com.core.ai;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/**
 * Minimal four-dot voice indicator.
 * LISTEN  : dots stretch into capsules that follow your voice level
 * THINK   : dots hop one after another
 * RESPOND : slow, soft wave while CORE answers
 * IDLE    : calm dots with a faint breathing glow
 * Pure Canvas, no dependencies (AIDE friendly, no lambdas).
 */
public class OrbView extends View {
    public static final int LISTEN = 0, THINK = 1, RESPOND = 2, IDLE = 3;

    private static final int[] COLORS = {0xFF00D7FF, 0xFFA78BFA, 0xFFFF4FA3, 0xFF4CD4A9};
    private static final float[] PHASE = {0f, 0.9f, 1.8f, 2.7f};

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final float[] h = new float[4];   // current heights
    private final float[] y = new float[4];   // current vertical offsets
    private final float dp;
    private volatile int state = LISTEN;
    private volatile float target = 0f;       // raw voice level 0..1
    private float level = 0f;                 // smoothed
    private final long t0 = System.nanoTime();

    public OrbView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        float base = 10f * dp;
        for (int i = 0; i < 4; i++) h[i] = base;
    }

    public void setState(int s) { state = s; postInvalidateOnAnimation(); }

    /** RecognitionListener.onRmsChanged value (roughly -2..10 dB). */
    public void setRms(float rms) {
        float v = (rms + 2f) / 12f;
        if (v < 0f) v = 0f; else if (v > 1f) v = 1f;
        if (v > target) target = v;
    }

    @Override
    protected void onMeasure(int w, int hh) {
        setMeasuredDimension((int) (88 * dp), (int) (40 * dp));
    }

    @Override
    protected void onDraw(Canvas cv) {
        float t = (System.nanoTime() - t0) / 1e9f;
        int st = state;
        int W = getWidth(), H = getHeight();
        float dot = 10f * dp, gap = 10f * dp;
        float total = 4 * dot + 3 * gap;
        float x0 = (W - total) / 2f, cy = H / 2f;

        // voice level: fast attack, slow release
        target *= 0.90f;
        level += (target - level) * 0.35f;

        for (int i = 0; i < 4; i++) {
            float wantH = dot, wantY = 0f, alpha = 1f;
            if (st == LISTEN) {
                float wob = 0.55f + 0.45f * (float) Math.sin(t * 7f + PHASE[i] * 2.1f);
                float idle = 0.12f * (float) Math.sin(t * 2.2f + PHASE[i]);
                wantH = dot + (22f * dp) * (level * wob + Math.max(idle, 0f));
            } else if (st == THINK) {
                float s = (float) Math.sin(t * 6f - PHASE[i] * 1.1f);
                wantY = -Math.max(s, 0f) * 9f * dp;
            } else if (st == RESPOND) {
                float s = (float) Math.sin(t * 3.2f + PHASE[i]);
                wantH = dot + (7f * dp) * (0.5f + 0.5f * s);
            } else {
                alpha = 0.55f + 0.25f * (float) Math.sin(t * 1.6f + PHASE[i]);
            }
            h[i] += (wantH - h[i]) * 0.28f;
            y[i] += (wantY - y[i]) * 0.35f;

            float cx = x0 + dot / 2f + i * (dot + gap);
            rect.set(cx - dot / 2f, cy + y[i] - h[i] / 2f, cx + dot / 2f, cy + y[i] + h[i] / 2f);

            int c = COLORS[i];
            glow.setColor(c);
            glow.setAlpha((int) (46 * alpha));
            float gr = dot * 0.9f;
            cv.drawRoundRect(rect.left - gr * 0.5f, rect.top - gr * 0.5f, rect.right + gr * 0.5f, rect.bottom + gr * 0.5f, dot, dot, glow);

            paint.setColor(c);
            paint.setAlpha((int) (255 * alpha));
            cv.drawRoundRect(rect, dot / 2f, dot / 2f, paint);
        }
        postInvalidateOnAnimation();
    }
}
