package com.core.ai;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.AlarmClock;
import android.provider.Settings;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;

/**
 * JS bridge (window.CORE_PHONE_NATIVE) for phone control.
 * Safety model:
 *  - Off until the user taps Allow in a native dialog (and has enabled the Accessibility service themselves).
 *  - SAFE actions (home, back, open app, scroll...) run straight away.
 *  - Anything else (tap, swipe, click, type, read, dial, sms, url) needs one native Allow tap per plan,
 *    which lists exactly what will happen. Remote plans can only be approved while CORE is on screen.
 *  - tap/click/type/read are refused on banking / wallet / password-manager style apps.
 */
public class PhoneBridge {
    private static final String[] SAFE = {"home", "back", "recents", "notifications", "quick", "scroll", "volume", "wait", "open", "alarm", "media", "torch", "screenshot", "lock", "power", "settings"};

    private final Activity activity;
    private final WebView web;
    private final SharedPreferences sp;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean running = false;

    public PhoneBridge(Activity a, WebView w) {
        activity = a;
        web = w;
        sp = a.getSharedPreferences("core_phone", Context.MODE_PRIVATE);
    }

    @JavascriptInterface
    public String status() {
        JSONObject o = new JSONObject();
        try {
            o.put("service", PhoneControlService.instance != null);
            o.put("enabled", sp.getBoolean("enabled", false));
            o.put("auto", sp.getBoolean("auto", true));
            o.put("sdk", Build.VERSION.SDK_INT);
        } catch (Exception e) { }
        return o.toString();
    }

    @JavascriptInterface
    public void openAccessibilitySettings() {
        ui.post(new Runnable() {
            public void run() {
                try { activity.startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); } catch (Exception e) { }
            }
        });
    }

    @JavascriptInterface
    public void requestEnable() {
        ui.post(new Runnable() {
            public void run() {
                if (activity.isFinishing()) return;
                new AlertDialog.Builder(activity)
                        .setTitle("Let CORE control this phone?")
                        .setMessage("CORE will be able to open apps and press Home/Back/scroll. Taps, typing, reading the screen, calls and links need your approval each time. Turn it off any time with /phone off, or switch off the CORE service in Accessibility settings.")
                        .setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { sp.edit().putBoolean("enabled", true).apply(); }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        });
    }

    @JavascriptInterface
    public void disable() { sp.edit().putBoolean("enabled", false).putBoolean("auto", false).apply(); }

    /** Auto mode: every plan runs without a per-plan Allow. Turned on only through this native dialog. */
    @JavascriptInterface
    public void requestAuto() {
        ui.post(new Runnable() {
            public void run() {
                if (activity.isFinishing()) return;
                new AlertDialog.Builder(activity)
                        .setTitle("Run everything without asking?")
                        .setMessage("CORE will tap, type, read the screen, open links and start calls/texts on its own, including plans sent from your cloud. Turn it off with /phone auto off.")
                        .setPositiveButton("Yes, auto", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { sp.edit().putBoolean("auto", true).putBoolean("enabled", true).apply(); }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        });
    }

    @JavascriptInterface
    public void autoOff() { sp.edit().putBoolean("auto", false).apply(); }

    @JavascriptInterface
    public void run(final String id, final String json) {
        final JSONArray acts;
        try { acts = parse(json); } catch (Exception e) { result(id, false, "bad action list", null); return; }
        if (acts.length() == 0) { result(id, false, "no actions", null); return; }
        if (!sp.getBoolean("enabled", false)) { result(id, false, "Phone control is off. Send /phone to turn it on.", null); return; }
        if (PhoneControlService.instance == null) { result(id, false, "The CORE accessibility service is not running. Send /phone and switch it on.", null); return; }
        if (running) { result(id, false, "Still busy with the previous plan.", null); return; }
        boolean confirm = false;
        for (int i = 0; i < acts.length(); i++) {
            if (!isSafe(acts.optJSONObject(i) == null ? "" : acts.optJSONObject(i).optString("do"))) confirm = true;
        }
        if (!confirm || sp.getBoolean("auto", true)) { start(id, acts); return; }
        if (!MainActivity.foreground) { result(id, false, "Open CORE on the phone to approve this plan.", null); return; }
        final String summary = describe(acts);
        ui.post(new Runnable() {
            public void run() {
                if (activity.isFinishing()) { result(id, false, "denied", null); return; }
                new AlertDialog.Builder(activity)
                        .setTitle("Approve this plan?")
                        .setMessage(summary)
                        .setCancelable(false)
                        .setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { start(id, acts); }
                        })
                        .setNegativeButton("Deny", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) { result(id, false, "You denied the plan.", null); }
                        })
                        .show();
            }
        });
    }

    @JavascriptInterface
    public void saveCloud(String url, String token) {
        if (url == null || token == null || !url.startsWith("https://")) return;
        sp.edit().putString("cloud_url", url).putString("cloud_token", token).apply();
    }

    @JavascriptInterface
    public void openAssistantSettings() {
        ui.post(new Runnable() {
            public void run() {
                String[] tries = {Settings.ACTION_VOICE_INPUT_SETTINGS, "android.settings.MANAGE_DEFAULT_APPS_SETTINGS", Settings.ACTION_SETTINGS};
                for (String a : tries) {
                    try { activity.startActivity(new Intent(a)); return; } catch (Exception e) { }
                }
            }
        });
    }

    // ------------------------------------------------------------------ wake word

    @JavascriptInterface
    public String wakeStatus() {
        JSONObject o = new JSONObject();
        try {
            o.put("running", WakeService.running);
            o.put("assistant", CoreVoiceService.instance != null);
            o.put("phrases", sp.getString("wake_phrases", WakeService.DEFAULT_PHRASES));
        } catch (Exception e) { }
        return o.toString();
    }

    @JavascriptInterface
    public void setWakePhrases(String csv) {
        if (csv == null) return;
        String c = csv.toLowerCase(java.util.Locale.US).replaceAll("\\s+or\\s+", ",").trim();
        if (c.length() > 0) sp.edit().putString("wake_phrases", c).apply();
    }

    @JavascriptInterface
    public void wakeStart() {
        ui.post(new Runnable() {
            public void run() {
                if (Build.VERSION.SDK_INT >= 23 && activity.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    activity.requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 902);
                    return;
                }
                if (Build.VERSION.SDK_INT >= 33 && activity.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    activity.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 903);
                }
                try {
                    Intent i = new Intent(activity, WakeService.class);
                    if (Build.VERSION.SDK_INT >= 26) activity.startForegroundService(i); else activity.startService(i);
                } catch (Exception e) { }
            }
        });
    }

    /** Asks Android to stop battery-saving from killing background listening. */
    @JavascriptInterface
    public void keepAlive() {
        ui.post(new Runnable() {
            public void run() {
                try {
                    if (Build.VERSION.SDK_INT >= 23) {
                        Intent i = new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                        i.setData(android.net.Uri.parse("package:" + activity.getPackageName()));
                        activity.startActivity(i);
                    }
                } catch (Exception e) { }
            }
        });
    }

    @JavascriptInterface
    public void wakeStop() {
        ui.post(new Runnable() {
            public void run() { try { activity.stopService(new Intent(activity, WakeService.class)); } catch (Exception e) { } }
        });
    }

    // ------------------------------------------------------------------ internals

    private JSONArray parse(String json) throws Exception {
        String t = json == null ? "" : json.trim();
        JSONArray src;
        if (t.startsWith("{")) {
            JSONObject o = new JSONObject(t);
            src = o.has("actions") ? o.getJSONArray("actions") : new JSONArray().put(o);
        } else src = new JSONArray(t);
        JSONArray out = new JSONArray();
        for (int i = 0; i < src.length() && i < 12; i++) out.put(src.get(i));
        return out;
    }

    static boolean isSafe(String d) {
        for (String s : SAFE) if (s.equals(d)) return true;
        return false;
    }

    static String cut(String s, int n) {
        if (s == null) return "";
        return s.length() > n ? s.substring(0, n) + "\u2026" : s;
    }

    static String describe(JSONArray acts) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < acts.length(); i++) {
            JSONObject a = acts.optJSONObject(i);
            if (a == null) continue;
            String d = a.optString("do");
            String line;
            if ("tap".equals(d)) line = "Tap at (" + a.optInt("x") + ", " + a.optInt("y") + ")";
            else if ("swipe".equals(d)) line = "Swipe on screen";
            else if ("click".equals(d)) line = "Press \u201c" + cut(a.optString("text"), 40) + "\u201d";
            else if ("type".equals(d)) line = "Type \u201c" + cut(a.optString("text"), 80) + "\u201d";
            else if ("read".equals(d)) line = "Read the text on screen";
            else if ("longpress".equals(d)) line = "Long-press at (" + a.optInt("x") + ", " + a.optInt("y") + ")";
            else if ("intent".equals(d)) line = "Run " + cut(a.optString("action", "VIEW") + " " + a.optString("data"), 80);
            else if ("dial".equals(d)) line = "Open dialer for " + cut(a.optString("number"), 24);
            else if ("sms".equals(d)) line = "Compose a text to " + cut(a.optString("number"), 24) + " (you press Send)";
            else if ("url".equals(d)) line = "Open " + cut(a.optString("url"), 80);
            else line = d;
            sb.append("\u2022 ").append(line).append('\n');
        }
        return sb.toString().trim();
    }

    private void start(final String id, final JSONArray acts) {
        running = true;
        new Thread(new Runnable() {
            public void run() {
                JSONArray steps = new JSONArray();
                boolean all = true;
                try {
                    for (int i = 0; i < acts.length(); i++) {
                        PhoneControlService s = PhoneControlService.instance;
                        JSONObject a = acts.optJSONObject(i);
                        JSONObject r;
                        if (s == null) { r = new JSONObject(); r.put("ok", false); r.put("error", "service stopped"); }
                        else if (a == null) { r = new JSONObject(); r.put("ok", false); r.put("error", "bad action"); }
                        else r = exec(s, a);
                        steps.put(r);
                        if (!r.optBoolean("ok")) { all = false; break; }
                        if (i < acts.length() - 1 && !"wait".equals(a.optString("do"))) Thread.sleep(250);
                    }
                } catch (Exception e) { all = false; }
                running = false;
                result(id, all, null, steps);
            }
        }).start();
    }

    static JSONObject exec(PhoneControlService s, JSONObject a) {
        String d = a.optString("do");
        JSONObject r = new JSONObject();
        boolean ok = false;
        String err = null;
        try {
            r.put("do", d);
            switch (d) {
                case "home": case "back": case "recents": case "notifications": case "quick": case "power": case "screenshot": case "lock":
                    ok = s.global(d); break;
                case "scroll":
                    ok = s.scroll(!"up".equals(a.optString("dir", "down"))); if (!ok) err = "nothing scrollable"; break;
                case "wait":
                    Thread.sleep(Math.min(a.optLong("ms", 500), 5000)); ok = true; break;
                case "open":
                    ok = s.openApp(a.optString("app")); if (!ok) err = "no app called \u201c" + a.optString("app") + "\u201d"; break;
                case "volume": {
                    AudioManager am = (AudioManager) s.getSystemService(Context.AUDIO_SERVICE);
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, "up".equals(a.optString("dir")) ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
                    ok = true; break;
                }
                case "alarm": {
                    Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                            .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
                            .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("min"))
                            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "CORE"));
                    launch(s, i); ok = true; break;
                }
                case "media": {
                    String k = a.optString("key", "playpause");
                    int code = "next".equals(k) ? KeyEvent.KEYCODE_MEDIA_NEXT
                            : ("prev".equals(k) || "previous".equals(k)) ? KeyEvent.KEYCODE_MEDIA_PREVIOUS
                            : "pause".equals(k) ? KeyEvent.KEYCODE_MEDIA_PAUSE
                            : "play".equals(k) ? KeyEvent.KEYCODE_MEDIA_PLAY : KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
                    AudioManager am = (AudioManager) s.getSystemService(Context.AUDIO_SERVICE);
                    am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
                    am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
                    ok = true; break;
                }
                case "torch": {
                    android.hardware.camera2.CameraManager cm = (android.hardware.camera2.CameraManager) s.getSystemService(Context.CAMERA_SERVICE);
                    String id = null;
                    for (String cid : cm.getCameraIdList()) {
                        Boolean f = cm.getCameraCharacteristics(cid).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                        if (f != null && f.booleanValue()) { id = cid; break; }
                    }
                    if (id == null) { err = "no flashlight on this phone"; break; }
                    cm.setTorchMode(id, a.optBoolean("on", true));
                    ok = true; break;
                }
                case "settings": {
                    String p = a.optString("page", "main");
                    String act = "wifi".equals(p) ? Settings.ACTION_WIFI_SETTINGS
                            : "bluetooth".equals(p) ? Settings.ACTION_BLUETOOTH_SETTINGS
                            : "airplane".equals(p) ? Settings.ACTION_AIRPLANE_MODE_SETTINGS
                            : "display".equals(p) ? Settings.ACTION_DISPLAY_SETTINGS
                            : "sound".equals(p) ? Settings.ACTION_SOUND_SETTINGS
                            : "battery".equals(p) ? Settings.ACTION_BATTERY_SAVER_SETTINGS
                            : "location".equals(p) ? Settings.ACTION_LOCATION_SOURCE_SETTINGS
                            : "apps".equals(p) ? Settings.ACTION_APPLICATION_SETTINGS : Settings.ACTION_SETTINGS;
                    launch(s, new Intent(act)); ok = true; break;
                }
                case "longpress":
                    if (s.isProtectedScreen()) { err = "blocked: sensitive app on screen"; break; }
                    ok = s.gesture((float) a.optDouble("x"), (float) a.optDouble("y"), (float) a.optDouble("x"), (float) a.optDouble("y"), a.optLong("ms", 800));
                    if (!ok) err = "long-press needs Android 7+"; break;
                case "intent": {
                    Intent i = new Intent(a.optString("action", Intent.ACTION_VIEW));
                    String data = a.optString("data", ""), type = a.optString("type", ""), pkg = a.optString("package", "");
                    if (data.length() > 0 && type.length() > 0) i.setDataAndType(Uri.parse(data), type);
                    else if (data.length() > 0) i.setData(Uri.parse(data));
                    else if (type.length() > 0) i.setType(type);
                    if (pkg.length() > 0) i.setPackage(pkg);
                    JSONObject ex = a.optJSONObject("extras");
                    if (ex != null) {
                        Iterator<String> it = ex.keys();
                        while (it.hasNext()) {
                            String key = it.next();
                            Object v = ex.get(key);
                            if (v instanceof Boolean) i.putExtra(key, ((Boolean) v).booleanValue());
                            else if (v instanceof Integer) i.putExtra(key, ((Integer) v).intValue());
                            else if (v instanceof Long) i.putExtra(key, ((Long) v).longValue());
                            else if (v instanceof Double) i.putExtra(key, ((Double) v).doubleValue());
                            else i.putExtra(key, String.valueOf(v));
                        }
                    }
                    launch(s, i); ok = true; break;
                }
                case "tap":
                    if (s.isProtectedScreen()) { err = "blocked: sensitive app on screen"; break; }
                    ok = s.gesture((float) a.optDouble("x"), (float) a.optDouble("y"), (float) a.optDouble("x"), (float) a.optDouble("y"), 60);
                    if (!ok) err = "tap needs Android 7+"; break;
                case "swipe":
                    if (s.isProtectedScreen()) { err = "blocked: sensitive app on screen"; break; }
                    ok = s.gesture((float) a.optDouble("x1"), (float) a.optDouble("y1"), (float) a.optDouble("x2"), (float) a.optDouble("y2"), a.optLong("ms", 300));
                    if (!ok) err = "swipe needs Android 7+"; break;
                case "click":
                    if (s.isProtectedScreen()) { err = "blocked: sensitive app on screen"; break; }
                    ok = s.clickText(a.optString("text")); if (!ok) err = "couldn\u2019t find \u201c" + cut(a.optString("text"), 30) + "\u201d to press"; break;
                case "type":
                    if (s.isProtectedScreen()) { err = "blocked: sensitive app on screen"; break; }
                    ok = s.typeText(a.optString("text")); if (!ok) err = "no text box is focused"; break;
                case "read":
                    if (s.isProtectedScreen()) { err = "blocked: sensitive app on screen"; break; }
                    r.put("text", s.readScreen(4000)); ok = true; break;
                case "dial":
                    launch(s, new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(a.optString("number"))))); ok = true; break;
                case "sms": {
                    Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(a.optString("number"))));
                    i.putExtra("sms_body", a.optString("text"));
                    launch(s, i); ok = true; break;
                }
                case "url": {
                    String u = a.optString("url");
                    if (!(u.startsWith("https://") || u.startsWith("http://"))) { err = "only http(s) links"; break; }
                    launch(s, new Intent(Intent.ACTION_VIEW, Uri.parse(u))); ok = true; break;
                }
                default: err = "unknown action \u201c" + d + "\u201d";
            }
        } catch (Exception e) { err = String.valueOf(e.getMessage()); ok = false; }
        try { r.put("ok", ok); if (err != null) r.put("error", err); } catch (Exception e) { }
        return r;
    }

    static void launch(Context c, Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }

    private void result(String id, boolean ok, String error, JSONArray steps) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", ok);
            if (error != null) o.put("error", error);
            if (steps != null) o.put("steps", steps);
            final String js = "window.CORE_PHONE_RESULT&&window.CORE_PHONE_RESULT(" + JSONObject.quote(id) + "," + JSONObject.quote(o.toString()) + ")";
            activity.runOnUiThread(new Runnable() {
                public void run() { try { if (web != null) web.evaluateJavascript(js, null); } catch (Exception e) { } }
            });
        } catch (Exception e) { }
    }
}
