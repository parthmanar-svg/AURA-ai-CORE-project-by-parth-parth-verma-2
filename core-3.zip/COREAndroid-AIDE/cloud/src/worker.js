// CORE Cloud - Cloudflare Worker (free tier is enough).
//   POST /v1/chat   streams a chat reply from an OpenAI-compatible upstream   (Bearer DEVICE_TOKEN)
//   GET  /ws/device the phone connects here to receive remote commands        (?t=DEVICE_TOKEN)
//   POST /v1/cmd    you send {"actions":[...]} to the phone and get the result (Bearer CONTROL_TOKEN)
//   POST /v1/gemini optional: Gemini chat (same body as /v1/chat, non-streaming JSON {text}).  Secret: GEMINI_API_KEY, var GEMINI_MODEL
//   POST /v1/stt    optional: Chirp speech-to-text. Body {audio:<base64>, mime, lang}. Secrets: GCP_SA_JSON (service-account JSON), var GCP_PROJECT
//   GET  /health
// Secrets: DEVICE_TOKEN, CONTROL_TOKEN, UPSTREAM_KEY.  Vars: UPSTREAM_URL, MODEL (see wrangler.toml).

const ALLOW_ORIGIN = 'https://appassets.androidplatform.net';
const CORS = {
  'Access-Control-Allow-Origin': ALLOW_ORIGIN,
  'Access-Control-Allow-Headers': 'Authorization, Content-Type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
};
const enc = new TextEncoder();

function json(obj, status) {
  return new Response(JSON.stringify(obj), { status: status || 200, headers: Object.assign({ 'Content-Type': 'application/json' }, CORS) });
}
function safeEq(a, b) {
  a = enc.encode(String(a || '')); b = enc.encode(String(b || ''));
  var d = a.length ^ b.length, n = Math.max(a.length, b.length);
  for (var i = 0; i < n; i++) d |= (a[i] || 0) ^ (b[i] || 0);
  return d === 0;
}
function bearer(req) {
  var h = req.headers.get('Authorization') || '';
  return h.indexOf('Bearer ') === 0 ? h.slice(7) : '';
}
function hub(env) { return env.HUB.get(env.HUB.idFromName('phone')); }

async function chat(req, env) {
  if (!env.DEVICE_TOKEN || !safeEq(bearer(req), env.DEVICE_TOKEN)) return json({ error: 'unauthorized' }, 401);
  if (!env.UPSTREAM_KEY) return json({ error: 'UPSTREAM_KEY is not set' }, 500);
  var body;
  try { body = await req.json(); } catch (e) { return json({ error: 'bad json' }, 400); }
  var msgs = Array.isArray(body.messages) ? body.messages.slice(-40) : [];
  if (!msgs.length) return json({ error: 'no messages' }, 400);
  msgs = msgs.map(function (m) {
    return { role: (m.role === 'assistant' || m.role === 'system') ? m.role : 'user', content: String(m.content == null ? '' : m.content).slice(0, 20000) };
  });
  var up = await fetch(env.UPSTREAM_URL || 'https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + env.UPSTREAM_KEY },
    body: JSON.stringify({
      model: env.MODEL || 'llama-3.3-70b-versatile',
      messages: msgs,
      max_tokens: Math.min(parseInt(body.max_tokens, 10) || 1024, 2048),
      stream: true
    })
  });
  if (!up.ok) return json({ error: 'upstream ' + up.status }, 502);
  // pass the stream straight through: first token reaches the phone as soon as the model emits it
  return new Response(up.body, { headers: Object.assign({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store' }, CORS) });
}

// ---- optional Gemini (needs GEMINI_API_KEY) -------------------------------------------------
async function gemini(req, env) {
  if (!env.DEVICE_TOKEN || !safeEq(bearer(req), env.DEVICE_TOKEN)) return json({ error: 'unauthorized' }, 401);
  if (!env.GEMINI_API_KEY) return json({ error: 'GEMINI_API_KEY is not set' }, 500);
  var body;
  try { body = await req.json(); } catch (e) { return json({ error: 'bad json' }, 400); }
  var msgs = Array.isArray(body.messages) ? body.messages.slice(-40) : [];
  if (!msgs.length) return json({ error: 'no messages' }, 400);
  var sys = msgs.filter(function (m) { return m.role === 'system'; }).map(function (m) { return String(m.content); }).join('\n');
  var contents = msgs.filter(function (m) { return m.role !== 'system'; }).map(function (m) {
    return { role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: String(m.content == null ? '' : m.content).slice(0, 20000) }] };
  });
  var payload = { contents: contents, generationConfig: { maxOutputTokens: Math.min(parseInt(body.max_tokens, 10) || 1024, 2048) } };
  if (sys) payload.systemInstruction = { parts: [{ text: sys.slice(0, 20000) }] };
  var r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/' + (env.GEMINI_MODEL || 'gemini-2.5-flash') + ':generateContent', {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': env.GEMINI_API_KEY }, body: JSON.stringify(payload)
  });
  if (!r.ok) return json({ error: 'gemini ' + r.status }, 502);
  var d = await r.json();
  var t = ((d.candidates || [])[0] || {}).content;
  return json({ text: t && t.parts ? t.parts.map(function (x) { return x.text || ''; }).join('') : '' });
}

// ---- optional Chirp STT via Google Cloud Speech-to-Text v2 (service account) ----------------
function b64u(buf) { var s = btoa(String.fromCharCode.apply(null, new Uint8Array(buf))); return s.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
async function gcpToken(env) {
  var sa = JSON.parse(env.GCP_SA_JSON), now = Math.floor(Date.now() / 1000);
  var head = b64u(enc.encode(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  var claim = b64u(enc.encode(JSON.stringify({ iss: sa.client_email, scope: 'https://www.googleapis.com/auth/cloud-platform', aud: 'https://oauth2.googleapis.com/token', iat: now, exp: now + 3600 })));
  var pem = sa.private_key.replace(/-----[A-Z ]+-----/g, '').replace(/\s+/g, '');
  var der = Uint8Array.from(atob(pem), function (c) { return c.charCodeAt(0); });
  var key = await crypto.subtle.importKey('pkcs8', der, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
  var sig = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, enc.encode(head + '.' + claim));
  var r = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=' + head + '.' + claim + '.' + b64u(sig) });
  var d = await r.json();
  if (!d.access_token) throw new Error('token');
  return d.access_token;
}
async function stt(req, env) {
  if (!env.DEVICE_TOKEN || !safeEq(bearer(req), env.DEVICE_TOKEN)) return json({ error: 'unauthorized' }, 401);
  if (!env.GCP_SA_JSON || !env.GCP_PROJECT) return json({ error: 'GCP_SA_JSON / GCP_PROJECT not set' }, 500);
  var body;
  try { body = await req.json(); } catch (e) { return json({ error: 'bad json' }, 400); }
  if (!body.audio || String(body.audio).length > 8000000) return json({ error: 'no audio or too large' }, 400);
  var tok;
  try { tok = await gcpToken(env); } catch (e) { return json({ error: 'gcp auth failed' }, 502); }
  var region = env.GCP_REGION || 'us-central1';
  var r = await fetch('https://' + region + '-speech.googleapis.com/v2/projects/' + env.GCP_PROJECT + '/locations/' + region + '/recognizers/_:recognize', {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + tok },
    body: JSON.stringify({ config: { autoDecodingConfig: {}, languageCodes: [body.lang || 'en-US'], model: 'chirp_2', features: { maxAlternatives: 5 } }, content: body.audio })
  });
  if (!r.ok) return json({ error: 'chirp ' + r.status }, 502);
  var d = await r.json(), alts = [];
  ((d.results || [])[0] || { alternatives: [] }).alternatives.forEach(function (a) { if (a.transcript) alts.push(a.transcript.trim()); });
  return json({ text: alts[0] || '', alts: alts });
}

export default {
  async fetch(req, env) {
    var url = new URL(req.url);
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    if (url.pathname === '/health') return json({ ok: true });
    if (url.pathname === '/v1/chat' && req.method === 'POST') return chat(req, env);
    if (url.pathname === '/v1/gemini' && req.method === 'POST') return gemini(req, env);
    if (url.pathname === '/v1/stt' && req.method === 'POST') return stt(req, env);
    if (url.pathname === '/ws/device') {
      if (!env.DEVICE_TOKEN || !safeEq(url.searchParams.get('t'), env.DEVICE_TOKEN)) return json({ error: 'unauthorized' }, 401);
      return hub(env).fetch(req);
    }
    if (url.pathname === '/v1/cmd' && req.method === 'POST') {
      if (!env.CONTROL_TOKEN || !safeEq(bearer(req), env.CONTROL_TOKEN)) return json({ error: 'unauthorized' }, 401);
      return hub(env).fetch(req);
    }
    return json({ error: 'not found' }, 404);
  }
};

// One Durable Object holds the phone's WebSocket and relays commands to it.
export class Hub {
  constructor(state) {
    this.state = state;
    this.waiting = new Map();
    // the phone sends "ping" every 25 s; answered without waking the object
    this.state.setWebSocketAutoResponse(new WebSocketRequestResponsePair('ping', 'pong'));
  }
  async fetch(req) {
    var url = new URL(req.url);
    if (url.pathname === '/ws/device') {
      if (req.headers.get('Upgrade') !== 'websocket') return json({ error: 'websocket required' }, 426);
      this.state.getWebSockets().forEach(function (old) { try { old.close(1000, 'replaced'); } catch (e) {} });
      var pair = new WebSocketPair();
      this.state.acceptWebSocket(pair[1]);
      return new Response(null, { status: 101, webSocket: pair[0] });
    }
    if (url.pathname === '/v1/cmd') {
      var body;
      try { body = await req.json(); } catch (e) { return json({ error: 'bad json' }, 400); }
      var actions = Array.isArray(body.actions) ? body.actions.slice(0, 12) : [];
      if (!actions.length) return json({ error: 'no actions' }, 400);
      var socks = this.state.getWebSockets();
      if (!socks.length) return json({ error: 'phone offline - open CORE and send /link on' }, 503);
      var id = crypto.randomUUID(), self = this;
      var result = new Promise(function (resolve) {
        var t = setTimeout(function () { self.waiting.delete(id); resolve({ ok: false, error: 'timeout' }); }, 60000);
        self.waiting.set(id, function (v) { clearTimeout(t); resolve(v); });
      });
      socks[0].send(JSON.stringify({ id: id, actions: actions }));
      return json(await result);
    }
    return json({ error: 'not found' }, 404);
  }
  webSocketMessage(ws, msg) {
    try {
      var j = JSON.parse(msg), f = this.waiting.get(j.id);
      if (f) { this.waiting.delete(j.id); f(j.result); }
    } catch (e) {}
  }
  webSocketClose(ws, code) { try { ws.close(code); } catch (e) {} }
}
